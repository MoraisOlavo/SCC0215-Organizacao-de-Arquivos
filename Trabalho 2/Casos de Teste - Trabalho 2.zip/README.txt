Arquivo zip gerado em: 23/12/2023 12:34:27 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 2