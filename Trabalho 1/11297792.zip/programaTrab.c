//11275338 Leonardo Antonetti da Motta
//11297792 Olavo Morais Borges Pereira
//Arquivo principal
#include "binarioNaTela.h"
#include <stdio.h>
typedef struct{ //Struct usado para armazenar um registro de Dados
	int tamanhoCidadeMae,	//Armazena o tamanho da string cidadeMae
	    tamanhoCidadeBebe,	//Armazena o tamanho da string cidadeBebe
	    idNascimento,	//Armazena o id do nascimento
	    idadeMae;		//Armazena a idade da mae
	char cidadeMae[97],	//String para armazenar a cidade de residência da mãe
	cidadeBebe[97],		//String para armazenar a cidade de nascimento do bebê
	dataNascimento[10],	//String para armazenar a data do nascimento
	sexoBebe,		//Char para armazenar o sexo do bebê
	estadoMae[2],		//String para armazenar o estado de residência da mãe
	estadoBebe[2];		//String para armazenar o estado de nascimento do bebê
}RegistroDados;

//Função que completa os campos com o caracter lixo $
void MarcarLixoArquivoGerado(FILE* fpArquivoGerado,int count){//Ponteiro do arquivo, quantos caracteres devem ser preenchidos
	char lixo='$';
	for(int i=0;i<count;i++){//Escreve $ count vezes
		fwrite(&lixo,1,1,fpArquivoGerado);
	}
}

//Cria o arquivo binário, define o registro de cabeçalho e retorna o ponteiro do arquivo
FILE* CriarArquivoGerado(char* nomeArquivoGerado){//Nome do arquivo binário
	//Criando o arquivo binário
	FILE* fpArquivoGerado=fopen(nomeArquivoGerado,"w+b");//Abre o arquivo no modo escrita binária
	if(fpArquivoGerado==NULL){//Se der algum erro ao abrir o arquivo
		return NULL;
	}

	//Definindo o registro de cabeçalho
	char status='0';//Usado para criar o campo "status" no registro de cabeçalho
	int aux=0;//Usado para criar os campos "RRNproxRegistro","numeroRegistrosInseridos","numeroRegistrosRemovidos" e "numeroRegistrosAtualizados" 
	fwrite(&status,1,1,fpArquivoGerado);//Insere '0' no campo status(arquivo inconsistente)
	for(int i=0;i<4;i++){//Realizado 4 vezes
		fwrite(&aux,4,1,fpArquivoGerado);//Insere 0 nos campos "RRNproxRegistro","numeroRegistrosInseridos","numeroRegistrosRemovidos" e "numeroRegistrosAtualizados" 
	}
	MarcarLixoArquivoGerado(fpArquivoGerado,111);//Preenche com $ os demais 111 caracteres do registro de cabeçalho

	return fpArquivoGerado;//Retorna o ponteiro do arquivo binário criado
}

//Lê um inteiro(4 bytes) do arquivo de entrada
void LerInteiroArquivoEntrada(FILE* fpArquivoEntrada,int* x){//ponteiro do arquivo e endereço da variável que vai armazenar o inteiro lido
	char c;
	fread(&c,1,1,fpArquivoEntrada);//Lê um caracter do arquivo
	if(c==','){//Se leu uma vírgula então não há inteiro para ser lido
		*x=-1;//variável recebe -1
	}else{
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Volta o ponteiro do arquivo um byte(volta o caracter lido)
		fscanf(fpArquivoEntrada,"%d,",x);//Lê o inteiro
	}
}

//Lê uma string do arquivo de entrada e retorna o tamamho da string lida
int LerStringArquivoEntrada(FILE* fpArquivoEntrada,char* str){//Ponteiro do arquivo e endereço para salvar a string
	int nCaracteres=0;//Armazena o número de caracteres lidos
	char charLido;//Armazena o caracter lido
	
	//Loop usado para ler e salvar cada caracter
	while(fread(&charLido,1,1,fpArquivoEntrada)){//Lê o caracter e armazena em charLido, sai do loop se o arquivo acabou
		if(charLido==',' || charLido=='\n'){//Se leu ',' ou '\n' então a string acabou
			break;//sai do loop
		}
		str[nCaracteres]=charLido;//Se leu um caracter válido então salva na string
		nCaracteres++;//Incrementa o número de caracteres lidos
	}

	if(nCaracteres==0){//Se tentou ler uma string que não está definida no arquivo de entrada(string nula)
		str[0]='\0';//Define o primeiro caracter da string como ' \0'
	}

	return nCaracteres;//Retorna o número de caracteres lidos
}

//Extrai um struct RegistroDados do arquivo de entrada, retorna 1 se a leitura foi bem sucedida, 0 caso contrário
int ObterRegistroArquivoEntrada(FILE* fpArquivoEntrada,RegistroDados* r){//Ponteiro do arquivo, endereço de um RegistroDados
	//Verificando se existe nascimento no arquivo de entrada para ser lido
	
	char teste;//Char usado para verificar se o arquivo acabou
	if(fread(&teste,1,1,fpArquivoEntrada)){//Tenta ler algum caracter, fread retorna 0 se o arquivo chegou ao fim
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Se o arquivo não acabou então volte o ponteiro um byte
	}else{
		return 0;//Se o arquivo acabou então retorne 0
	}

	//Lendo o nascimento e salvando no RegistroDados
	
	r->tamanhoCidadeMae=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeMae);//Lê a cidade da mãe e também obtém seu tamanho
	r->tamanhoCidadeBebe=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeBebe);//Lê a cidade do bebê e também obtém seu tamanho
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idNascimento));//Lê o id de nascimento
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idadeMae));//Lê a idade da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->dataNascimento);//Lê a data de nascimento
	LerStringArquivoEntrada(fpArquivoEntrada,&(r->sexoBebe));//Lê o sexo do bebê
	if(r->sexoBebe=='\0'){//Se o sexo do bebê não foi especificado então armazena 0 no struct RegistroDados
		r->sexoBebe='0';
	}
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoMae);//Lê o estado da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoBebe);//Lê o estado do bebê
	return 1;//Retorna 1 indicando que a leitura foi bem sucedida
}

//Salva uma string no arquivo binário gerado, usado para salvar string em campos de tamanho fixo
void SalvarStringArquivoGerado(char* str,int tamanho,FILE* fpArquivoGerado){//string que será salva, tamanho da string e ponteiro do arquivo
	if(str[0]=='\0'){//Se o primeiro char da string é '\0'(string nula)
		fwrite(str,1,1,fpArquivoGerado);//Insere o '\0'
		MarcarLixoArquivoGerado(fpArquivoGerado,tamanho-1);//Prenche o resto do campo com $
	}else{//Se a string não é nula
		fwrite(str,1,tamanho,fpArquivoGerado);//Salva a string
	}
}

//Salva um registro no arquivo binário gerado
void SalvarRegistroArquivoGerado(FILE* fpArquivoGerado,RegistroDados r){//ponteiro do arquivo e RegistroDados que será salvo
	//Posicionando o ponteiro para a inserção no arquivo binário gerado	
	int auxInt;//Usada para ler e escrever "RRNproxRegistro" e "numeroRegistrosInseridos"
	fseek(fpArquivoGerado,1,SEEK_SET);//Coloca  o ponteiro sobre o byte offset 1(RRNproxRegistro)
	fread(&auxInt,4,1,fpArquivoGerado);//Lê RRNproxRegistro e armazena em auxInt
	fseek(fpArquivoGerado,(1+auxInt)*128,SEEK_SET);//Coloca o ponteiro sobre o byte offset da posição indicada pelo "RRNproxRegistro"

	//Salvando o RegistroDados
	fwrite(&(r.tamanhoCidadeMae),4,1,fpArquivoGerado);//Escreve o tamanhoCidadeMae no arquivo binário
	fwrite(&(r.tamanhoCidadeBebe),4,1,fpArquivoGerado);//Escreve o tamanhoCidadeBebe no arquivo binário

	if(r.tamanhoCidadeMae!=0){//Se cidadeMae não é nula
		fwrite(r.cidadeMae,1,r.tamanhoCidadeMae,fpArquivoGerado);//Escreve cidadeMae no arquivo binário
	}
	if(r.tamanhoCidadeBebe!=0){//Se cidadeBebe não é nula
		fwrite(r.cidadeBebe,1,r.tamanhoCidadeBebe,fpArquivoGerado);//Escreve cidadeBebe no arquivo
	}
	MarcarLixoArquivoGerado(fpArquivoGerado,97-r.tamanhoCidadeMae-r.tamanhoCidadeBebe);//Preenche o resto dos campos de string de tamanho variável com lixo

	fwrite(&(r.idNascimento),4,1,fpArquivoGerado);//Escreve o idNascimento no arquivo binário
	fwrite(&(r.idadeMae),4,1,fpArquivoGerado);//Escreve a idadeMae no arquvivo binário

	SalvarStringArquivoGerado(r.dataNascimento,10,fpArquivoGerado);//Salva a dataNascimento no arquivo binário
	fwrite(&(r.sexoBebe),1,1,fpArquivoGerado);//Salva o sexoBebe no arquivo binário
	SalvarStringArquivoGerado(r.estadoMae,2,fpArquivoGerado);//Salva estadoMae no arquivo binário
	SalvarStringArquivoGerado(r.estadoBebe,2,fpArquivoGerado);//Salva estadoBebe no arquivo binário

	//Incrementando os campos do registro de cabeçalho
	auxInt++;//Incrementa RRNproxRegistro
	fseek(fpArquivoGerado,1,SEEK_SET);//Coloca o ponteiro no byte offset 1(campo RRNproxRegistro)
	fwrite(&auxInt,4,1,fpArquivoGerado);//Escreve o novo RRNproxRegistro

	fread(&auxInt,4,1,fpArquivoGerado);//Lê o numeroRegistrosInseridos e salva em auxInt
	auxInt++;//Incrementa numeroRegistros
	fseek(fpArquivoGerado,-4,SEEK_CUR);//Volta o ponteiro 4 bytes
	fwrite(&auxInt,4,1,fpArquivoGerado);//Salva o novo numeroRegistrosInseridos
}

//Lê o arquivo gerado e obtém dele um RegistroDados, retorna 0 se o arquivo binário acabou ou se tentou ler um registro lógicamente removido,retorna 1 se a leitura foi bem sucedida
int ObterRegistroArquivoGerado(FILE* fpArquivoGerado,RegistroDados* r){//Ponteiro do arquivo gerado e endereço de um RegistroDados para salvar os valores lidos
	if(fread(&(r->tamanhoCidadeMae),4,1,fpArquivoGerado)){//Lê um inteiro e armazena em r->tamanhoCidadeMae, fread retorna zero se o arquivo acabou
		if(r->tamanhoCidadeMae==-1){//Se valor lido é -1
			fseek(fpArquivoGerado,124,SEEK_CUR);//Coloca o ponteiro no início do próximo registro
			return 0;//leitura não foi bem sucedida
		}
		fread(&(r->tamanhoCidadeBebe),4,1,fpArquivoGerado);//Lê o tamanhoCidadeBebe
		fread(r->cidadeMae,1,r->tamanhoCidadeMae,fpArquivoGerado);//Lê a cidadeMae
		fread(r->cidadeBebe,1,r->tamanhoCidadeBebe,fpArquivoGerado);//Lê a cidadeBebe
		fseek(fpArquivoGerado,97-(r->tamanhoCidadeMae)-(r->tamanhoCidadeBebe),SEEK_CUR);//Pula o lixo das string de tamanho variável
		fread(&(r->idNascimento),4,1,fpArquivoGerado);//Lê o idNascimento
		fread(&(r->idadeMae),4,1,fpArquivoGerado);//Lê a idadeMae
		fread(r->dataNascimento,1,10,fpArquivoGerado);//Lê a dataNascimento
		fread(&(r->sexoBebe),1,1,fpArquivoGerado);//Lê o sexoBebe
		fread(r->estadoMae,1,2,fpArquivoGerado);//Lê o estadoMae
		fread(r->estadoBebe,1,2,fpArquivoGerado);//Lê o estadoBebe
		return 1;//Leitura bem sucedida
	}
	return 0;//Erro, arquivo acabou
}

//Função que exibe uma string sem '\0' no final
void ExibirString(char* str,int tam){//Ponteiro para início da string, tamanho da string
        if(tam==0 || str[0]=='\0'){//Se o tamanho da string é zero(campo de tamanho variavel) ou se ela começa com '\0'(campo de tamanho fixo) então exibe "-"
                printf("-");
        }else{//String não é nula
                for(int i=0;i<tam;i++){//Exibe um caracter por vez
                        printf("%c",str[i]);
                }
        }
}

//Função que recebe um struct RegistroDados e o exibe na tela conforme especificação da funcionalidade 2
void MostrarRegistroDados(RegistroDados r){//Registro a ser exibido
        printf("Nasceu em ");
        ExibirString(r.cidadeBebe,r.tamanhoCidadeBebe);//Exibe a cidade de nascimento do bebê
        printf("/");
        ExibirString(r.estadoBebe,2);//Exibe o estado de nascimento do bebê
        printf(", em ");
        ExibirString(r.dataNascimento,10);//Exibe a data do nascimento
        printf(", um bebê de sexo ");
        if(r.sexoBebe=='0'){//Analisa o valor de sexoBebe para exibir o sexo da criança
                printf("IGNORADO.\n");
        }else if(r.sexoBebe=='1'){
                printf("MASCULINO.\n");
        }else{
                printf("FEMININO.\n");
        }
}

//Abre o arquivo de entrada, cria o arquivo binário, lê os nascimentos do arquivo de entrada e os armazena no arquivo binário, fechas os 2 arquivos e chama a binarioNaTela
void Funcionalidade1(char* nomeArquivoEntrada,char* nomeArquivoGerado){//Nome do arquivo de entrada, nome do arquivo binário a ser criado
	//Abertura dos arquivos
	FILE* fpArquivoGerado=CriarArquivoGerado(nomeArquivoGerado);//Cria o arquivo binário
	FILE* fpArquivoEntrada=fopen(nomeArquivoEntrada,"r");//Abre o arquivo de entrada no modo leitura
	
	char status='1';//Usado no final da função para salvar o status do arquivo binário
	
	if(fpArquivoEntrada==NULL || fpArquivoGerado==NULL){//Se houve algum erro na hora de abrir os arquivos
		printf("Falha no carregamento do arquivo.\n");
	}else{//Se abriu os arquivos
		
		//Loop que obtém os registros do arquivo de entrada e os salva no arquivo binário gerado
		fseek(fpArquivoEntrada,88,SEEK_SET);//Pula a primeira linha do arquivo de entrada
		RegistroDados r;//Registro que será usado para armazenar as informações antes de serem armazenadas no arquivo binário
		while(ObterRegistroArquivoEntrada(fpArquivoEntrada,&r)){//Lê o arquivo de entrada e obtém um RegistroDados, sai do loop quando o arquivo de entrada acabar
			SalvarRegistroArquivoGerado(fpArquivoGerado,r);	//Salva no arquivo binário o RegistroDados obtido
		}

		//Fecha os arquivos e chama a binarioNaTela
		fseek(fpArquivoGerado,0,SEEK_SET);//Coloca o ponteiro no início do arquivo gerado
		fwrite(&status,1,1,fpArquivoGerado);//Salva '1' no campo status do arquivo gerado
		fclose(fpArquivoGerado);//Fecha o arquivo gerado
		fclose(fpArquivoEntrada);//Fechr o arquivo de entrada
		binarioNaTela(nomeArquivoGerado);//Chama a binarioNaTela passando o nome do arquivo binário
	}
}

//Abre o arquivo gerado no modo leitura e exibe na tela os registros obtidos
void Funcionalidade2(char* nomeArquivoGerado){//Nome do arquivo binário
	FILE* fpArquivoGerado=fopen(nomeArquivoGerado,"rb");//Abre o arquivo no modo leitura
	
	//Variáveis usadas para controlar a exibição dos registros
	char status;//char usado para armazenar o valor do campo status
	int nRegistrosInseridos;//inteiro usado para armazenar o valor do campo numeroRegistroInseridos
	int nRegistrosMostrados=0;//Armazena quantos registros foram exibos
	
	//Verificar se o arquivo abriu
	if(fpArquivoGerado==NULL){//Se o arquivo não existe
		printf("Falha no processamento do arquivo.\n");
	}else{//Se o arquivo foi aberto com sucesso

		//Verificar a consistência do arquivo
		fread(&status,1,1,fpArquivoGerado);//Lê o campo status
		if(status=='0'){//Se o arquivo está inconsistente
			printf("Falha no processamento do arquivo.\n");
		}else{//Se o arquivo está consistente

			//Verificar se existe registros no arquivo	
			fseek(fpArquivoGerado,5,SEEK_SET);//Coloca o ponteiro no campo numeroRegistrosInseridos
			fread(&nRegistrosInseridos,4,1,fpArquivoGerado);//Obtém o valor do campo numeroRegistrosInseridos
			if(nRegistrosInseridos==0){//Se não há registros
				printf("Registro inexistente.\n");
			}else{//Se existe registros

				//Loop para exibir os arquivos	
				RegistroDados r;//RegistroDados que armazena as informações a serem exibidas
				fseek(fpArquivoGerado,128,SEEK_SET);//Pula o registro de cabeçalho do arquivo gerado
				while(nRegistrosMostrados<nRegistrosInseridos){//Enquanto tiver registro a ser exibido
					if(ObterRegistroArquivoGerado(fpArquivoGerado,&r)){//Obtém um registro do arquivo binário, função retorna 0 se o registro estiver lógicamente removido ou aconter algum erro	
						//Se conseguiu ler um registro válido
						MostrarRegistroDados(r);//Exibe o registro na tela
						nRegistrosMostrados++;//Incrementa o número de registros mostrados
					}
				}
			}
		}
		fclose(fpArquivoGerado);//Fecha o arquivo 
	}
}

//Lê a funcionalidade desejada e faz a leitura dos argumentos necessários
int main(){
	char op,nomeArquivoEntrada[100],nomeArquivoGerado[100];//char para armazenar a operação desejada e strings para armazenar os argumentos
	scanf("%c",&op);//Lê a operação desejada
	if(op=='1'){//Funcionalidade 1
		scanf("%s %s",nomeArquivoEntrada,nomeArquivoGerado);//Lê o nome do arquivo de entrada e do arquivo gerado
		Funcionalidade1(nomeArquivoEntrada,nomeArquivoGerado);//Chama a funcionalidade1
	}else if(op=='2'){//Funcionalidade 2
		scanf("%s",nomeArquivoGerado);//Lê o nome do arquivo gerado
		Funcionalidade2(nomeArquivoGerado);//Chama a funcionalidade 2
	}
	return 0;//Sai do programa
}
