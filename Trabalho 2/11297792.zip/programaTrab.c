//11275338 Leonardo Antonetti da Motta
//11297792 Olavo Morais Borges Pereira
//Arquivo principal
#include "binarioNaTela.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct{ //Struct usado para armazenar um registro de Dados
	int tamanhoCidadeMae,	//Armazena o tamanho da string cidadeMae
	    tamanhoCidadeBebe,	//Armazena o tamanho da string cidadeBebe
	    idNascimento,	//Armazena o id do nascimento
	    idadeMae;		//Armazena a idade da mae
	char cidadeMae[97],	//String para armazenar a cidade de residência da mãe
	cidadeBebe[97],		//String para armazenar a cidade de nascimento do bebê
	dataNascimento[10],	//String para armazenar a data do nascimento
	sexoBebe,		//Char para armazenar o sexo do bebê
	estadoMae[2],		//String para armazenar o estado de residência da mãe
	estadoBebe[2];		//String para armazenar o estado de nascimento do bebê
}RegistroDados;

typedef struct{//Struct usado para armazenar os valores do registro de cabeçalho do arquivo binário
	char status;//Armazena o valor do campo status
	int valoresCabecalho[4];//armazena os campos inteiros do registro de cabeçalho
	//Posição 0: RRNproxRegistro
	//Posição 1: numeroRegistrosInseridos
	//Posição 2: numeroRegistrosRemovidos
	//Posição 3: numeroRegistrosAtualizados
}Cabecalho;

typedef struct{
	char campoBusca[15];
	char valorBuscaStr[98];
	int valorBuscaInt;
}CelulaBusca;

//Função que completa os campos com o caracter lixo $
void MarcarLixoArquivoGerado(FILE* fpArquivoGerado,int count){//Ponteiro do arquivo, quantos caracteres devem ser preenchidos
	char lixo='$';
	for(int i=0;i<count;i++){//Escreve $ count vezes
		fwrite(&lixo,1,1,fpArquivoGerado);
	}
}

//Função que armazena os valores do struct cabeçalho no arquivo binário
void ArmazenarCabecalho(FILE* fpArquivoGerado,Cabecalho* c){
	fseek(fpArquivoGerado,0,SEEK_SET);//Coloca o ponteiro no início do arquivo
	fwrite(&(c->status),1,1,fpArquivoGerado);//Armazena o status no arquivo binário
	fwrite(c->valoresCabecalho,4,4,fpArquivoGerado);//Armazena no arquivo binário o vetor com o restante dos valores
}

//Função que obtém o Registro de cabeçalho do arquivo binário e armazena em ram
void ObterCabecalho(FILE* fpArquivoGerado,Cabecalho* c){
	fseek(fpArquivoGerado,0,SEEK_SET);//Coloca o ponteiro no início do arquivo
	fread(&(c->status),1,1,fpArquivoGerado);//Lê o status do arquivo binário 
	fread(c->valoresCabecalho,4,4,fpArquivoGerado);//Lê os campos inteiros do arquivo binário
}

//Cria o arquivo binário, define o registro de cabeçalho e retorna o ponteiro do arquivo
FILE* CriarArquivoGerado(char* nomeArquivoGerado,Cabecalho* c){//Nome do arquivo binário
	//Criando o arquivo binário
	FILE* fpArquivoGerado=fopen(nomeArquivoGerado,"w+b");//Abre o arquivo no modo escrita binária
	if(fpArquivoGerado==NULL){//Se der algum erro ao abrir o arquivo
		return NULL;
	}

	//Definindo o registro de cabeçalho no arquivo binário e no struct em memória ram
	c->status='0';//Define o campo 'status' do struct em ram
	for(int i=0;i<4;i++){//Realizado 4 vezes
		c->valoresCabecalho[i]=0;//Insere 0 nos campos "RRNproxRegistro","numeroRegistrosInseridos","numeroRegistrosRemovidos" e "numeroRegistrosAtualizados" do struct em ram 
	}
	ArmazenarCabecalho(fpArquivoGerado,c);//Armazena no arquivo binário os campos do cabeçalho
	MarcarLixoArquivoGerado(fpArquivoGerado,111);//Preenche com $ os demais 111 caracteres do registro de cabeçalho do arquivo binário

	return fpArquivoGerado;//Retorna o ponteiro do arquivo binário criado
}

FILE* AbrirArquivoGeradoLeitura(char* nomeArquivoGerado,Cabecalho* c){
	FILE* fpArquivoGerado=fopen(nomeArquivoGerado,"rb");
	if(fpArquivoGerado==NULL){
		printf("Falha no processamento do arquivo.\n");
		return NULL;
	}
	ObterCabecalho(fpArquivoGerado,c);
	if(c->status=='0'){
		printf("Falha no processamento do arquivo.\n");
		return NULL;
	}

	if(c->valoresCabecalho[1]==0){
		printf("Registro Inexistente.\n");
		return NULL;
	}
	
	return fpArquivoGerado;
}

FILE* AbrirArquivoGeradoEscrita(char* nomeArquivoGerado,Cabecalho* c){
	FILE* fpArquivoGerado=fopen(nomeArquivoGerado,"rb+");
	if(fpArquivoGerado==NULL){
		printf("Falha no processamento do arquivo.\n");
		return NULL;
	}
	ObterCabecalho(fpArquivoGerado,c);
	if(c->status!='1'){
		printf("Falha no processamento do arquivo.\n");
		return NULL;
	}
	c->status='0';
	ArmazenarCabecalho(fpArquivoGerado,c);
	return fpArquivoGerado;
}

void FecharArquivoGerado(FILE* fpArquivoGerado,Cabecalho* c){
	c->status='1';
	ArmazenarCabecalho(fpArquivoGerado,c);
	fclose(fpArquivoGerado);
}

//Lê um inteiro(4 bytes) do arquivo de entrada
void LerInteiroArquivoEntrada(FILE* fpArquivoEntrada,int* x){//ponteiro do arquivo e endereço da variável que vai armazenar o inteiro lido
	char c;
	fread(&c,1,1,fpArquivoEntrada);//Lê um caracter do arquivo
	if(c==','){//Se leu uma vírgula então não há inteiro para ser lido
		*x=-1;//variável recebe -1
	}else{
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Volta o ponteiro do arquivo um byte(volta o caracter lido)
		fscanf(fpArquivoEntrada,"%d,",x);//Lê o inteiro
	}
}

//Lê uma string do arquivo de entrada e retorna o tamamho da string lida
int LerStringArquivoEntrada(FILE* fpArquivoEntrada,char* str){//Ponteiro do arquivo e endereço para salvar a string
	int nCaracteres=0;//Armazena o número de caracteres lidos
	char charLido;//Armazena o caracter lido
	
	//Loop usado para ler e salvar cada caracter
	while(fread(&charLido,1,1,fpArquivoEntrada)){//Lê o caracter e armazena em charLido, sai do loop se o arquivo acabou
		if(charLido==',' || charLido=='\n'){//Se leu ',' ou '\n' então a string acabou
			break;//sai do loop
		}
		str[nCaracteres]=charLido;//Se leu um caracter válido então salva na string
		nCaracteres++;//Incrementa o número de caracteres lidos
	}

	if(nCaracteres==0){//Se tentou ler uma string que não está definida no arquivo de entrada(string nula)
		str[0]='\0';//Define o primeiro caracter da string como ' \0'
	}

	return nCaracteres;//Retorna o número de caracteres lidos
}

//Extrai um struct RegistroDados do arquivo de entrada, retorna 1 se a leitura foi bem sucedida, 0 caso contrário
int ObterRegistroArquivoEntrada(FILE* fpArquivoEntrada,RegistroDados* r){//Ponteiro do arquivo, endereço de um RegistroDados
	//Verificando se existe nascimento no arquivo de entrada para ser lido
	
	char teste;//Char usado para verificar se o arquivo acabou
	if(fread(&teste,1,1,fpArquivoEntrada)){//Tenta ler algum caracter, fread retorna 0 se o arquivo chegou ao fim
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Se o arquivo não acabou então volte o ponteiro um byte
	}else{
		return 0;//Se o arquivo acabou então retorne 0
	}

	//Lendo o nascimento e salvando no RegistroDados
	
	r->tamanhoCidadeMae=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeMae);//Lê a cidade da mãe e também obtém seu tamanho
	r->tamanhoCidadeBebe=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeBebe);//Lê a cidade do bebê e também obtém seu tamanho
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idNascimento));//Lê o id de nascimento
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idadeMae));//Lê a idade da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->dataNascimento);//Lê a data de nascimento
	LerStringArquivoEntrada(fpArquivoEntrada,&(r->sexoBebe));//Lê o sexo do bebê
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoMae);//Lê o estado da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoBebe);//Lê o estado do bebê
	return 1;//Retorna 1 indicando que a leitura foi bem sucedida
}

//Salva uma string no arquivo binário gerado, usado para salvar string em campos de tamanho fixo
void SalvarStringArquivoGerado(char* str,int tamanho,FILE* fpArquivoGerado){//string que será salva, tamanho da string e ponteiro do arquivo
	if(str[0]=='\0'){//Se o primeiro char da string é '\0'(string nula)
		fwrite(str,1,1,fpArquivoGerado);//Insere o '\0'
		MarcarLixoArquivoGerado(fpArquivoGerado,tamanho-1);//Prenche o resto do campo com $
	}else{//Se a string não é nula
		fwrite(str,1,tamanho,fpArquivoGerado);//Salva a string
	}
}

void SalvarRegistroArquivoGerado(FILE* fpArquivoGerado,RegistroDados r,int manterLixo){
	//Salvando o RegistroDados
        fwrite(&(r.tamanhoCidadeMae),4,1,fpArquivoGerado);//Escreve o tamanhoCidadeMae no arquivo binário
        fwrite(&(r.tamanhoCidadeBebe),4,1,fpArquivoGerado);//Escreve o tamanhoCidadeBebe no arquivo binário

        if(r.tamanhoCidadeMae!=0){//Se cidadeMae não é nula
                fwrite(r.cidadeMae,1,r.tamanhoCidadeMae,fpArquivoGerado);//Escreve cidadeMae no arquivo binário
        }
        if(r.tamanhoCidadeBebe!=0){//Se cidadeBebe não é nula
                fwrite(r.cidadeBebe,1,r.tamanhoCidadeBebe,fpArquivoGerado);//Escreve cidadeBebe no arquivo
        }
	if(manterLixo==0){
        	MarcarLixoArquivoGerado(fpArquivoGerado,97-r.tamanhoCidadeMae-r.tamanhoCidadeBebe);//Preenche o resto dos campos de string de tamanho variável com lixo
	}else{
		fseek(fpArquivoGerado,97-r.tamanhoCidadeMae-r.tamanhoCidadeBebe,SEEK_CUR);
	}
        fwrite(&(r.idNascimento),4,1,fpArquivoGerado);//Escreve o idNascimento no arquivo binário
        fwrite(&(r.idadeMae),4,1,fpArquivoGerado);//Escreve a idadeMae no arquvivo binário

        SalvarStringArquivoGerado(r.dataNascimento,10,fpArquivoGerado);//Salva a dataNascimento no arquivo binário
	if(r.sexoBebe=='\0'){
		r.sexoBebe='0';
	}
	fwrite(&(r.sexoBebe),1,1,fpArquivoGerado);//Salva o sexoBebe no arquivo binário
        SalvarStringArquivoGerado(r.estadoMae,2,fpArquivoGerado);//Salva estadoMae no arquivo binário
        SalvarStringArquivoGerado(r.estadoBebe,2,fpArquivoGerado);//Salva estadoBebe no arquivo binário

}

//Salva um registro no arquivo binário gerado
void InserirRegistroFinalArquivoGerado(FILE* fpArquivoGerado,Cabecalho* c,RegistroDados r){//ponteiro do arquivo e RegistroDados que será salvo
	//Posicionando o ponteiro para a inserção no arquivo binário gerado	
	fseek(fpArquivoGerado,(1+c->valoresCabecalho[0])*128,SEEK_SET);//Coloca o ponteiro sobre o byte offset da posição indicada pelo "RRNproxRegistro"
	
	//Insere no final
	SalvarRegistroArquivoGerado(fpArquivoGerado,r,0);
	
	//Incrementando os campos do registro de cabeçalho
	c->valoresCabecalho[0]++;//Incrementa RRNproxRegistro
	c->valoresCabecalho[1]++;//Incrementa numeroRegistrosInseridos
}

void RemoverRegistroArquivoGerado(FILE* fpArquivoGerado,Cabecalho* c){
	c->valoresCabecalho[1]--;
	c->valoresCabecalho[2]++;
	int aux=-1;
	fwrite(&aux,4,1,fpArquivoGerado);
}

//Lê o arquivo gerado e obtém dele um RegistroDados, retorna 0 se o arquivo binário acabou ou se tentou ler um registro lógicamente removido,retorna 1 se a leitura foi bem sucedida
int ObterRegistroArquivoGerado(FILE* fpArquivoGerado,RegistroDados* r){//Ponteiro do arquivo gerado e endereço de um RegistroDados para salvar os valores lidos
	if(fread(&(r->tamanhoCidadeMae),4,1,fpArquivoGerado)){//Lê um inteiro e armazena em r->tamanhoCidadeMae, fread retorna zero se o arquivo acabou
		if(r->tamanhoCidadeMae==-1){//Se valor lido é -1
			fseek(fpArquivoGerado,124,SEEK_CUR);//Coloca o ponteiro no início do próximo registro
			return -1;//leu registro lógicamente removido
		}
		fread(&(r->tamanhoCidadeBebe),4,1,fpArquivoGerado);//Lê o tamanhoCidadeBebe
		fread(r->cidadeMae,1,r->tamanhoCidadeMae,fpArquivoGerado);//Lê a cidadeMae
		fread(r->cidadeBebe,1,r->tamanhoCidadeBebe,fpArquivoGerado);//Lê a cidadeBebe
		fseek(fpArquivoGerado,97-(r->tamanhoCidadeMae)-(r->tamanhoCidadeBebe),SEEK_CUR);//Pula o lixo das string de tamanho variável
		fread(&(r->idNascimento),4,1,fpArquivoGerado);//Lê o idNascimento
		fread(&(r->idadeMae),4,1,fpArquivoGerado);//Lê a idadeMae
		fread(r->dataNascimento,1,10,fpArquivoGerado);//Lê a dataNascimento
		fread(&(r->sexoBebe),1,1,fpArquivoGerado);//Lê o sexoBebe
		fread(r->estadoMae,1,2,fpArquivoGerado);//Lê o estadoMae
		fread(r->estadoBebe,1,2,fpArquivoGerado);//Lê o estadoBebe
		return 1;//Leitura bem sucedida
	}
	return 0;//Erro, arquivo acabou
}

//Função que exibe uma string sem '\0' no final
void ExibirString(char* str,int tam){//Ponteiro para início da string, tamanho da string
        if(tam==0 || str[0]=='\0'){//Se o tamanho da string é zero(campo de tamanho variavel) ou se ela começa com '\0'(campo de tamanho fixo) então exibe "-"
                printf("-");
        }else{//String não é nula
                for(int i=0;i<tam;i++){//Exibe um caracter por vez
                        printf("%c",str[i]);
                }
        }
}

//Função que recebe um struct RegistroDados e o exibe na tela conforme especificação da funcionalidade 2
void MostrarRegistroDados(RegistroDados r){//Registro a ser exibido
	printf("Nasceu em ");
        ExibirString(r.cidadeBebe,r.tamanhoCidadeBebe);//Exibe a cidade de nascimento do bebê
        printf("/");
        ExibirString(r.estadoBebe,2);//Exibe o estado de nascimento do bebê
        printf(", em ");
        ExibirString(r.dataNascimento,10);//Exibe a data do nascimento
        printf(", um bebê de sexo ");
        if(r.sexoBebe=='0'){//Analisa o valor de sexoBebe para exibir o sexo da criança
                printf("IGNORADO.\n");
        }else if(r.sexoBebe=='1'){
                printf("MASCULINO.\n");
        }else{
                printf("FEMININO.\n");
        }
}

int VerificarCampoRegistro(RegistroDados* r,CelulaBusca* cb){
	if(strncmp(cb->campoBusca,"tamanhoCidadeMae",16)==0){
		if(r->tamanhoCidadeMae==cb->valorBuscaInt){
			return 1;
		}
	}else if(strncmp(cb->campoBusca,"tamanhoCidadeBebe",17)==0){
                if(r->tamanhoCidadeBebe==cb->valorBuscaInt){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"idNascimento",12)==0){
                if(r->idNascimento==cb->valorBuscaInt){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"idadeMae",8)==0){
                if(r->idadeMae==cb->valorBuscaInt){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"cidadeMae",9)==0){
                if(r->tamanhoCidadeMae>0 && strncmp(r->cidadeMae,cb->valorBuscaStr,r->tamanhoCidadeMae)==0){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"cidadeBebe",10)==0){
		if(r->tamanhoCidadeBebe>0 && strncmp(r->cidadeBebe,cb->valorBuscaStr,r->tamanhoCidadeBebe)==0){
			return 1;
                }
        }else if(strncmp(cb->campoBusca,"dataNascimento",14)==0){
                if(strncmp(r->dataNascimento,cb->valorBuscaStr,10)==0){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"sexoBebe",8)==0){
                if(cb->valorBuscaStr[0]=='\0'){
			cb->valorBuscaStr[0]='0';
		}
		if(r->sexoBebe==cb->valorBuscaStr[0]){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"estadoMae",9)==0){
                if(strncmp(r->estadoMae,cb->valorBuscaStr,2)==0){
                        return 1;
                }
        }else if(strncmp(cb->campoBusca,"estadoBebe",10)==0){
                if(strncmp(r->estadoBebe,cb->valorBuscaStr,2)==0){
                        return 1;
                }
        }
	
	return 0;
}

int VerificarBuscaCombinada(RegistroDados* r,CelulaBusca* vetorCb,int nCelulas){
	if(r->tamanhoCidadeMae==-1){
		return 0;
	}
	
	for(int i=0;i<nCelulas;i++){
		if(VerificarCampoRegistro(r,vetorCb+i)==0){
			return 0;
		}
	}
	return 1;
}

int IrParaRRN(FILE* fpArquivoGerado,int RRN){
	if(fseek(fpArquivoGerado,128*(RRN+1),SEEK_SET)!=0){
		return 0;
	}
	int aux;
	fread(&aux,4,1,fpArquivoGerado);
	fseek(fpArquivoGerado,-4,SEEK_CUR);
	if(aux==-1){
		return -1;
	}
	return 1;
}

int ObterInteiroUsuario(){
        char str[97];
        scan_quote_string(str);
        if(strcmp(str,"")==0){
                return -1;
        }
        return atoi(str);
}

void ObterVetorCelulaBusca(int nCelulas,CelulaBusca* vetorCb){
	for(int i=0;i<nCelulas;i++){
		scanf("%s",vetorCb[i].campoBusca);
		if(strcmp(vetorCb[i].campoBusca,"tamanhoCidadeMae")==0 || 
		   strcmp(vetorCb[i].campoBusca,"tamanhoCidadeBebe")==0 ||
		   strcmp(vetorCb[i].campoBusca,"idNascimento")==0 ||
		   strcmp(vetorCb[i].campoBusca,"idadeMae")==0){
		   	vetorCb[i].valorBuscaInt=ObterInteiroUsuario();
		   }else{
		   	scan_quote_string(vetorCb[i].valorBuscaStr);
		   }
	}
}

void ObterRegistroUsuario(RegistroDados* r){
	scan_quote_string(r->cidadeMae);
	r->tamanhoCidadeMae=strlen(r->cidadeMae);
	scan_quote_string(r->cidadeBebe);
	r->tamanhoCidadeBebe=strlen(r->cidadeBebe);
	r->idNascimento=ObterInteiroUsuario();
	r->idadeMae=ObterInteiroUsuario();
	scan_quote_string(r->dataNascimento);
	scan_quote_string(&(r->sexoBebe));
	if(r->sexoBebe=='\0'){
		r->sexoBebe='0';
	}
	scan_quote_string(r->estadoMae);
	scan_quote_string(r->estadoBebe);
}

void AlterarCampoRegistro(RegistroDados* r,CelulaBusca* cb){
	if(strncmp(cb->campoBusca,"idNascimento",12)==0){
                r->idNascimento=cb->valorBuscaInt;
        }else if(strncmp(cb->campoBusca,"idadeMae",8)==0){
                r->idadeMae=cb->valorBuscaInt;
        }else if (strncmp(cb->campoBusca,"cidadeMae",9)==0){
                strncpy(r->cidadeMae,cb->valorBuscaStr,strlen(cb->valorBuscaStr));
		r->tamanhoCidadeMae=strlen(cb->valorBuscaStr);
        }else if(strncmp(cb->campoBusca,"cidadeBebe",10)==0){
                strncpy(r->cidadeBebe,cb->valorBuscaStr,strlen(cb->valorBuscaStr));
		r->tamanhoCidadeBebe=strlen(cb->valorBuscaStr);
        }else if(strncmp(cb->campoBusca,"dataNascimento",14)==0){
                strncpy(r->dataNascimento,cb->valorBuscaStr,10);
        }else if(strncmp(cb->campoBusca,"sexoBebe",8)==0){
		r->sexoBebe=cb->valorBuscaStr[0];
		if(r->sexoBebe=='\0'){
			r->sexoBebe='0';
		}
        }else if(strncmp(cb->campoBusca,"estadoMae",9)==0){
                strncpy(r->estadoMae,cb->valorBuscaStr,2);
        }else if(strncmp(cb->campoBusca,"estadoBebe",10)==0){
                strncpy(r->estadoBebe,cb->valorBuscaStr,2);
        }
}

void AlterarRegistro(RegistroDados* r,CelulaBusca* vetorCb,int nCelulasBusca){
	for(int i=0;i<nCelulasBusca;i++){
		AlterarCampoRegistro(r,vetorCb+i);
	}
}

void AtualizarRegistroArquivoGerado(FILE* fpArquivoGerado,Cabecalho* c,RegistroDados* r){
	SalvarRegistroArquivoGerado(fpArquivoGerado,*r,1);
	c->valoresCabecalho[3]++;
}

//Abre o arquivo de entrada, cria o arquivo binário, lê os nascimentos do arquivo de entrada e os armazena no arquivo binário, fechas os 2 arquivos e chama a binarioNaTela
void Funcionalidade1(FILE* fpArquivoEntrada,FILE* fpArquivoGerado,Cabecalho* c){//Nome do arquivo de entrada, nome do arquivo binário a ser criado	
	//Loop que obtém os registros do arquivo de entrada e os salva no arquivo binário gerado
	fseek(fpArquivoEntrada,88,SEEK_SET);//Pula a primeira linha do arquivo de entrada
	RegistroDados r;//Registro que será usado para armazenar as informações antes de serem armazenadas no arquivo binário
	while(ObterRegistroArquivoEntrada(fpArquivoEntrada,&r)){//Lê o arquivo de entrada e obtém um RegistroDados, sai do loop quando o arquivo de entrada acabar
		InserirRegistroFinalArquivoGerado(fpArquivoGerado,c,r);//Salva no arquivo binário o RegistroDados obtido
	}

	//Fecha os arquivos e chama a binarioNaTela
	fclose(fpArquivoEntrada);
	FecharArquivoGerado(fpArquivoGerado,c);
}


//Abre o arquivo gerado no modo leitura e exibe na tela os registros obtidos
void Funcionalidade2(FILE* fpArquivoGerado){//Nome do arquivo binário
	//Loop para exibir os arquivos	
	RegistroDados r;//RegistroDados que armazena as informações a serem exibidas
	fseek(fpArquivoGerado,128,SEEK_SET);//Pula o registro de cabeçalho do arquivo gerado
	while(ObterRegistroArquivoGerado(fpArquivoGerado,&r)){//Enquanto numero de registros exibidos < numero de registros inseridos
		if(r.tamanhoCidadeMae!=-1){//Obtém um registro do arquivo binário, função retorna 0 se o registro estiver lógicamente removido ou aconter algum erro	
			//Se conseguiu ler um registro válido
			MostrarRegistroDados(r);//Exibe o registro na tela
		}
	}
	fclose(fpArquivoGerado);
}

void Funcionalidade3(FILE* fpArquivoGerado){
	int nCelulasBusca,contador=0;
	scanf("%d",&nCelulasBusca);
	CelulaBusca vetorCb[nCelulasBusca];
	ObterVetorCelulaBusca(nCelulasBusca,vetorCb);

	RegistroDados r;
	fseek(fpArquivoGerado,128,SEEK_SET);
	while(ObterRegistroArquivoGerado(fpArquivoGerado,&r)){
		if(VerificarBuscaCombinada(&r,vetorCb,nCelulasBusca)==1){
			MostrarRegistroDados(r);
			contador++;
		}
	}
	if(contador==0){
		printf("Registro Inexistente.\n");
	}
	fclose(fpArquivoGerado);
}

void Funcionalidade4(FILE* fpArquivoGerado){
	int RRN;
	RegistroDados r;
	scanf("%d",&RRN);
	if(IrParaRRN(fpArquivoGerado,RRN)==1){
		ObterRegistroArquivoGerado(fpArquivoGerado,&r);
		MostrarRegistroDados(r);
	}else{
		printf("Registro Inexistente.\n");
	}
	fclose(fpArquivoGerado);
}

void Funcionalidade5(FILE* fpArquivoGerado,Cabecalho* c){
	int n,m;
	RegistroDados r;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&m);
		CelulaBusca vetorCb[m];
		ObterVetorCelulaBusca(m,vetorCb);
		fseek(fpArquivoGerado,128,SEEK_SET);
		while(ObterRegistroArquivoGerado(fpArquivoGerado,&r)){
			if(VerificarBuscaCombinada(&r,vetorCb,m)==1){
				fseek(fpArquivoGerado,-128,SEEK_CUR);
				RemoverRegistroArquivoGerado(fpArquivoGerado,c);
				fseek(fpArquivoGerado,124,SEEK_CUR);
			}
		}

	}
	FecharArquivoGerado(fpArquivoGerado,c);
}

void Funcionalidade6(FILE* fpArquivoGerado,Cabecalho* c){
	int n;
	RegistroDados r;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		ObterRegistroUsuario(&r);
		InserirRegistroFinalArquivoGerado(fpArquivoGerado,c,r);
	}
	FecharArquivoGerado(fpArquivoGerado,c);
}

void Funcionalidade7(FILE* fpArquivoGerado,Cabecalho* c){
	int n,rrn,m;
	RegistroDados r;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d %d",&rrn,&m);
		IrParaRRN(fpArquivoGerado,rrn);
		CelulaBusca vetorCb[m];
		ObterVetorCelulaBusca(m,vetorCb);
		if(ObterRegistroArquivoGerado(fpArquivoGerado,&r)==1){
			AlterarRegistro(&r,vetorCb,m);
			fseek(fpArquivoGerado,-128,SEEK_CUR);
			AtualizarRegistroArquivoGerado(fpArquivoGerado,c,&r);
		}
	}
	FecharArquivoGerado(fpArquivoGerado,c);
}

//Lê a funcionalidade desejada e faz a leitura dos argumentos necessários
int main(){
	char op,nomeArquivoEntrada[100],nomeArquivoGerado[100];//char para armazenar a operação desejada e strings para armazenar os argumentos
	FILE* fpArquivoEntrada,*fpArquivoGerado;
	Cabecalho c;
	scanf("%c",&op);//Lê a operação desejada

	if(op=='1'){
		scanf("%s %s",nomeArquivoEntrada,nomeArquivoGerado);//Lê o nome do arquivo de entrada e do arquivo gerado
		fpArquivoGerado=CriarArquivoGerado(nomeArquivoGerado,&c);//Cria o arquivo binário
		fpArquivoEntrada=fopen(nomeArquivoEntrada,"r");//Abre o arquivo de entrada no modo leitura

		if(fpArquivoEntrada==NULL || fpArquivoGerado==NULL){
			printf("Falha no carregamento do arquivo.\n");
			return 0;
		}

	}else if(op=='2'){
		scanf("%s",nomeArquivoGerado);
		fpArquivoGerado=fopen(nomeArquivoGerado,"rb");
		if(fpArquivoGerado==NULL){
			printf("Falha no processamento do arquivo.\n");
			return 0;
		}
		ObterCabecalho(fpArquivoGerado,&c);
		if(c.status=='0'){
			printf("Falha no processamento do arquivo.\n");
			return 0;
		}

		if(c.valoresCabecalho[1]==0){
			printf("Registro inexistente.\n");
			return 0;
		}

	}else if(op=='3' || op=='4'){
		scanf("%s",nomeArquivoGerado);
		fpArquivoGerado=AbrirArquivoGeradoLeitura(nomeArquivoGerado,&c);
	}else{
		scanf("%s",nomeArquivoGerado);
		fpArquivoGerado=AbrirArquivoGeradoEscrita(nomeArquivoGerado,&c);
	}

	if(fpArquivoGerado==NULL){
		return 0;
	}

	switch(op){
		case '1'://Funcionalidade 1
			Funcionalidade1(fpArquivoEntrada,fpArquivoGerado,&c);//Chama a funcionalidade1
			break;
		case '2'://Funcionalidade 2
			Funcionalidade2(fpArquivoGerado);//Chama a funcionalidade 2
			break;
		case '3'://Funcionalidade 3
			Funcionalidade3(fpArquivoGerado);
			break;
		case '4'://Funcionalidade 4
			Funcionalidade4(fpArquivoGerado);
			break;
		case '5'://Funcionalidade 5
			Funcionalidade5(fpArquivoGerado,&c);
			break;
		case '6'://Funcionalidade 6
			Funcionalidade6(fpArquivoGerado,&c);
			break;
		case '7'://Funcionalidade 7
			Funcionalidade7(fpArquivoGerado,&c);
			break;
	}

	if(op=='1' || (op>='5' && op<='7')){
		binarioNaTela(nomeArquivoGerado);
	}
	return 0;//Sai do programa
}
