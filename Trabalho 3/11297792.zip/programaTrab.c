//11275338 Leonardo Antonetti da Motta
//11297792 Olavo Morais Borges Pereira
//Arquivo principal

#include "binarioNaTela.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{ //Struct usado para armazenar um registro de Dados
	int tamanhoCidadeMae,	//Armazena o tamanho da string cidadeMae
	    tamanhoCidadeBebe,	//Armazena o tamanho da string cidadeBebe
	    idNascimento,	//Armazena o id do nascimento
	    idadeMae;		//Armazena a idade da mae
	char cidadeMae[97],	//String para armazenar a cidade de residência da mãe
	cidadeBebe[97],		//String para armazenar a cidade de nascimento do bebê
	dataNascimento[10],	//String para armazenar a data do nascimento
	sexoBebe,		//Char para armazenar o sexo do bebê
	estadoMae[2],		//String para armazenar o estado de residência da mãe
	estadoBebe[2];		//String para armazenar o estado de nascimento do bebê
}RegistroDados;

typedef struct{//Struct usado para armazenar os valores do registro de cabeçalho do arquivo binário
	char status;//Armazena o valor do campo status
	int valoresCabecalho[4];//armazena os campos inteiros do registro de cabeçalho
	//Posição 0: RRNproxRegistro
	//Posição 1: numeroRegistrosInseridos
	//Posição 2: numeroRegistrosRemovidos
	//Posição 3: numeroRegistrosAtualizados
}Cabecalho;

typedef struct{//Struct usado para armazenar nome do campo e respectivo valor durante uma busca ou uma alteração
	char campoBusca[15];//Armazena o campo buscado
	char valorBuscaStr[98];//Armazena uma string com o valor buscado
	int valorBuscaInt;//Armazena um inteiro com o valor buscado
}ParCampoValor;

typedef struct{//Strutct usado para armazenar uma chave de busca e um RRN referência no arquivod de dados
	int chaveBusca;//chave usada para identificar os Registros(idNascimento)
	int RRNReferencia;//RRN do Registro no arquivo de dados com a chave procurada
}Chave;

typedef struct{//Struct usado para armazenar em ram um nó da árvore B
	int nivel;//Nível do nó
	int nChaves;//Número de chaves no nó
	Chave vetorChaves[5];//Vetor de chaves do nó
	int ponteirosFilhos[6];//Vetor de ponteiros do nó
}NoArvoreB;

//Obtém um nó do arquivo de árvore B
void ObterNoArvoreB(FILE* fpArvoreB,int RRNDesejado,NoArvoreB* no){//Ponteiro do arquivo da árvore, RRN do nó desejado, Endereço para armazenar as informações
	fseek(fpArvoreB,72*(1+RRNDesejado),SEEK_SET);//Posiciona o ponteiro no nó desejado
	fread(&(no->nivel),4,1,fpArvoreB);//Lê e armazena o nível do nó
	fread(&(no->nChaves),4,1,fpArvoreB);//Lê e armazena o número de chaves do nó
	for(int i=0;i<5;i++){//Executa 5 vezes
		fread(&((no->vetorChaves+i)->chaveBusca),4,1,fpArvoreB);//Lê e armazena a i-ésima chave
		fread(&((no->vetorChaves+i)->RRNReferencia),4,1,fpArvoreB);//Lê e armazena o i-ésimo RRN referencia
	}
	for(int i=0;i<6;i++){//Executa 6 vezes
		fread(no->ponteirosFilhos+i,4,1,fpArvoreB);//Lê e armazena o i-ésimo ponteiro
	}
}

//Salva um nó no arquivo de árvore B
void SalvarNoArvoreB(FILE* fpArvoreB,int RRNNo,NoArvoreB no){//Ponteiro do arquivo da árvore B, RRN em que o nó será salvo e Nó a ser salvo
	int aux=-1;
	fseek(fpArvoreB,(1+RRNNo)*72,SEEK_SET);//Posiciona o ponteiro no RRN desejado
	fwrite(&(no.nivel),4,1,fpArvoreB);//Salva o nível do nó
	fwrite(&(no.nChaves),4,1,fpArvoreB);//Salva o número de Chaves no nó
	for(int i=0;i<no.nChaves;i++){//Executa para cada chave no nó
		fwrite(&((no.vetorChaves+i)->chaveBusca),4,1,fpArvoreB);//Salva a i-ésima chave de busca
		fwrite(&((no.vetorChaves+i)->RRNReferencia),4,1,fpArvoreB);//Salva o i-ésimo RRN referência
	}

	for(int i=0;i<5-no.nChaves;i++){//Completa com -1 as chaves de buscas e RRNReferencia que não existem
		fwrite(&aux,4,1,fpArvoreB);//Salva -1 na chave
		fwrite(&aux,4,1,fpArvoreB);//Salve -1 no RRNReferencia
	}

	for(int i=0;i<no.nChaves+1;i++){//Executa para cada ponteiro do nó
		fwrite(no.ponteirosFilhos+i,4,1,fpArvoreB);//Salva o ponteiro
	}
	for(int i=0;i<5-no.nChaves;i++){//Completa com -1 os ponteiros inexistentes
		fwrite(&aux,4,1,fpArvoreB);//Salva -1 no ponteiro
	}
}

//Cria um novo nó, faz a inserção da chave promovida, escolhe qual chave será a nova promovida e salva o novo nó
void split(FILE* fpArvoreB,Cabecalho* c,NoArvoreB* noAtual,int pos,Chave* chavePromovida,int* ponteiroPromovido){//Ponteiro do arquivo da árvore, Cabeçalho do arquivo da árvore, Endereço do Nó atual(que está cheio e será dividido)
	//posição do ponteiro que aponta para o nó da chave promovida, Endereço da chave promovida e endereço do ponteiro promovido
	
	//Variáveis para trabalhar com a chave e o ponteiro adicional
	Chave novaChave;
	int novoPonteiro;

	if(pos==5){//Se a chave promovida estava no nó apontado pelo último ponteiro
		novaChave=*chavePromovida;//Chave promovida vai para o última posição
		novoPonteiro=*ponteiroPromovido;//Ponteiro promovido vai para a última posição de ponteiro
	}else{
		novaChave=noAtual->vetorChaves[4];//Chave extra recebe a última chave
		novoPonteiro=noAtual->ponteirosFilhos[5];//Ponteiro extra recebe o último ponteiro
		noAtual->ponteirosFilhos[5]=noAtual->ponteirosFilhos[4];//Última posição do vetor de ponteiros recebe a penúltima posição
		for(int i=3;i>=pos;i--){//Joga as chaves e seus ponteiros uma posição para frente, começando da penúltima chave
			noAtual->vetorChaves[i+1]=noAtual->vetorChaves[i];
			noAtual->ponteirosFilhos[i+1]=noAtual->ponteirosFilhos[i];
		}
		noAtual->vetorChaves[pos]=*chavePromovida;//Insere a chave promovida na posição correta
		noAtual->ponteirosFilhos[pos]=noAtual->ponteirosFilhos[pos+1];//Define o ponteiro da chave promovida
		noAtual->ponteirosFilhos[pos+1]=*ponteiroPromovido;//Insere o ponteiro promovido
	}

	//Dividindo o nó
	noAtual->nChaves=3;//Define o número de chaves do nó atual como 3
	*chavePromovida=noAtual->vetorChaves[3];//Define a nova chave a ser promovida como a chave na 4 posição
	*ponteiroPromovido=c->valoresCabecalho[2];//Define o ponteiro promovido como a proxRRN do cabeçalho
	c->valoresCabecalho[2]++;//Incrementa o proxRRN do cabeçalho
	NoArvoreB novoNo;//Cria um novo nó
	novoNo.nChaves=2;//Define o número de chaves do novo nó como 2
	novoNo.nivel=noAtual->nivel;//Define o nível do novo nó como o nível do nó atual
	novoNo.vetorChaves[0]=noAtual->vetorChaves[4];//Define a primeira chave do novo nó
	novoNo.vetorChaves[1]=novaChave;//Define a segunda chave do novo nó
	novoNo.ponteirosFilhos[0]=noAtual->ponteirosFilhos[4];//Define os ponteiros do novo nó
	novoNo.ponteirosFilhos[1]=noAtual->ponteirosFilhos[5];
	novoNo.ponteirosFilhos[2]=novoPonteiro;
	SalvarNoArvoreB(fpArvoreB,*ponteiroPromovido,novoNo);//Salva o novo nó no arquivo de árvore B
}

//Inserção recursiva na árvore B
int InsercaoArvoreBRecursiva(FILE* fpArvoreB,Cabecalho* c,int RRNAtual,Chave chaveInserida,Chave* chavePromovida,int* ponteiroPromovido){//Ponteiro do arquivo da árvore B, Cabecalho da árvore, RRN atual,
	//Chave a ser inserida na árvore, Endereço da Chave promovida e endereço do ponteiro promovido
	
	if(RRNAtual==-1){//Se está num nó inexistente
		*ponteiroPromovido=-1;//Promove -1
		*chavePromovida=chaveInserida;//Promove a chave a ser inserida
		return 1;//PROMOTION
	}
	//Se não está num nó inexistente

	NoArvoreB noAtual;//Cria o nó atual
	ObterNoArvoreB(fpArvoreB,RRNAtual,&noAtual);//Obtém o nó atual do arquivo da árvore
	int pos=noAtual.nChaves;//assume que o próximo nó a ser chamado é o último
	for(int i=0;i<noAtual.nChaves;i++){//Varre as chaves do nó
		if(chaveInserida.chaveBusca==noAtual.vetorChaves[i].chaveBusca){//Se a i-ésima chave de busca for igual a chave de busca a ser inserida
			return -1;//Erro, chave já inserida
		}
		if(chaveInserida.chaveBusca<noAtual.vetorChaves[i].chaveBusca){//Se encontrar uma chave de busca maior que a chave de busca a ser inserida
			pos=i;//Salva em pos a posição da chave
			break;//Sai do for
		}
	}

	//Chama a função recursivamente e armazena o resultado de retorno
	int valorRetorno=InsercaoArvoreBRecursiva(fpArvoreB,c,noAtual.ponteirosFilhos[pos],chaveInserida,chavePromovida,ponteiroPromovido);//Ponteiro da árvore, cabeçalho, RRN do nó a ser chamado, chave a ser inserida
	//Endereço da chave promovida e endereço do ponteiro promovido
	if(valorRetorno==-1 || valorRetorno==0){//Se retorno erro ou NO_PROMOTION
		return valorRetorno;//retorno o valor também
	}

	//Se retorno PROMOTION

	if(noAtual.nChaves<5){//Se tem espaço no nó atual
		noAtual.ponteirosFilhos[noAtual.nChaves+1]=noAtual.ponteirosFilhos[noAtual.nChaves];//Move o último ponteiro para frente
		for(int i=noAtual.nChaves-1;i>=pos;i--){//Joga as chaves e ponteiros para frente, começando da última chave até a chave da posição pos
			noAtual.vetorChaves[i+1]=noAtual.vetorChaves[i];
			noAtual.ponteirosFilhos[i+1]=noAtual.ponteirosFilhos[i];
		}

		noAtual.vetorChaves[pos]=*chavePromovida;//Insere a chave promovida
		noAtual.ponteirosFilhos[pos]=noAtual.ponteirosFilhos[pos+1];//Insere o ponteiro da chave promovida
		noAtual.ponteirosFilhos[pos+1]=*ponteiroPromovido;//Insere o ponteiro promovido
		noAtual.nChaves++;//Incrementa o número de chaves do nó
		SalvarNoArvoreB(fpArvoreB,RRNAtual,noAtual);//Salva o nó no arquivo da árvore
		return 0;//Retorna NO_PROMOTION
	}
	//Se tiver que inserir em um nó cheio
	split(fpArvoreB,c,&noAtual,pos,chavePromovida,ponteiroPromovido);//Chama a split
	SalvarNoArvoreB(fpArvoreB,RRNAtual,noAtual);//Salva o nó atual no arquivo da árvore
	return 1;//Retorna PROMOTION

}

//Faz busca recursiva na árvore B
int BuscarArvoreBRecursiva(FILE* fpArvoreB,int RRNNoAtual,int idProcurado,int* nNiveisPercorridos){//Arquivo da árvore, RRN do nó atual, chave de busca procurada e endereço da variável que conta quantos níveis percorridos
	if(RRNNoAtual==-1){//Se chegou em um nó inexistente
		return -1;//Retorna -1
	}
	NoArvoreB noAtual;//Cria o nó atual
	ObterNoArvoreB(fpArvoreB,RRNNoAtual,&noAtual);//Obtém o nó atual
	*nNiveisPercorridos+=1;//Incrementa o número de nós percorridos
	int pos=noAtual.nChaves;//Assume que continua no último ponteiro
	for(int i=0;i<noAtual.nChaves;i++){//Percorre as chaves do nó
		if(noAtual.vetorChaves[i].chaveBusca==idProcurado){//Se a i-ésima chave possui a chave de busca desejada
			return noAtual.vetorChaves[i].RRNReferencia;//Retorna o RRNReferencia da i-ésima chave
		}
		if(idProcurado<noAtual.vetorChaves[i].chaveBusca){//Se a i-ésima chave possui chave de busca maior que a desejada
			pos=i;//Define a posição como i
			break;//Sai do for
		}
	}
	return BuscarArvoreBRecursiva(fpArvoreB,noAtual.ponteirosFilhos[pos],idProcurado,nNiveisPercorridos);//Chama a função recursivamente
}

//Chama e gerencia função de inserção recursiva
void InsercaoArvoreB(FILE* fpArvoreB,Cabecalho* c,Chave ch){//Ponteiro do arquivo de árvore B, Cabecalho da árvore e chave a ser inserida
	//Variáveis para receber a chave e ponteiros promovidos
	Chave chavePromovida;
	int ponteiroPromovido;
	//Chama a função recursiva e armazena o valor de retorno
	int retorno=InsercaoArvoreBRecursiva(fpArvoreB,c,c->valoresCabecalho[0],ch,&chavePromovida,&ponteiroPromovido);//Ponteiro do arquivo da árvore, Cabecalho, RRN do nó raiz, chave a ser inserida
	//Endereço para armazenar a chave promovida e endereço para armazenar o ponteiro promovido
	if(retorno==-1){//Se retornou ERRO
		printf("Falha no processamento do arquivo.\n");	
	}else{
		if(retorno==1){//Se retornou PROMOTION
			NoArvoreB novoNo;//Cria um novo nó
			novoNo.nChaves=1;//Define o numero de chaves como 1
			novoNo.nivel=c->valoresCabecalho[1]+1;//Nível da nova raiz é o nível da árvore+1
			novoNo.vetorChaves[0]=chavePromovida;//Define a primeira chave como a chave promovida
			novoNo.ponteirosFilhos[0]=c->valoresCabecalho[0];//Define o primeiro ponteiro como o RRN do nó raiz
			novoNo.ponteirosFilhos[1]=ponteiroPromovido;//Define o segundo ponteiro como o ponteiro promovido
			SalvarNoArvoreB(fpArvoreB,c->valoresCabecalho[2],novoNo);//Salva o novo nó no arquivo de árvore
			c->valoresCabecalho[0]=c->valoresCabecalho[2];//Atualiza a raiz
			c->valoresCabecalho[2]++;//Incrementa o proxRRN
			c->valoresCabecalho[1]++;//Incrementa o nível da árvore
		}
		c->valoresCabecalho[3]++;//Incrementa o número de chaves
	}
}

//Função que completa o arquivo binário com o caracter lixo $
void MarcarLixoArquivoBinario(FILE* fpArquivoBinario,int count){//Ponteiro do arquivo, quantos caracteres devem ser preenchidos
	char lixo='$';
	for(int i=0;i<count;i++){//Escreve $ count vezes
		fwrite(&lixo,1,1,fpArquivoBinario);
	}
}

//Função que salva os valores do struct cabeçalho no arquivo binário
void SalvarCabecalho(FILE* fpArquivoBinario,Cabecalho* c){
	fseek(fpArquivoBinario,0,SEEK_SET);//Coloca o ponteiro no início do arquivo
	fwrite(&(c->status),1,1,fpArquivoBinario);//Armazena o status no arquivo binário
	fwrite(c->valoresCabecalho,4,4,fpArquivoBinario);//Armazena no arquivo binário o vetor com o restante dos valores
}

//Função que obtém o Registro de cabeçalho do arquivo binário e armazena em ram
void ObterCabecalho(FILE* fpArquivoBinario,Cabecalho* c){
	fseek(fpArquivoBinario,0,SEEK_SET);//Coloca o ponteiro no início do arquivo
	fread(&(c->status),1,1,fpArquivoBinario);//Lê o status do arquivo binário 
	fread(c->valoresCabecalho,4,4,fpArquivoBinario);//Lê os campos inteiros do Registro de Cabecalho do arquivo binário
}

//Cria o arquivo binário, define o registro de cabeçalho no arquivo binário, cria o struct Cabeçalho e retorna o ponteiro do arquivo
FILE* CriarArquivoBinario(char* nomeArquivoBinario,Cabecalho* c,int* erro,int tamanhoLixo){//Nome do arquivo binário, Endereço do struct Cabecalho e endereço para armazenar o tipo do erro
	//Criando o arquivo binário
	FILE* fpArquivoBinario=fopen(nomeArquivoBinario,"w+b");//Abre o arquivo no modo escrita binária
	if(fpArquivoBinario==NULL){//Se der algum erro ao abrir o arquivo
		*erro=1;//Define o tipo do erro
		return NULL;//Encerra a função
	}

	//Definindo o registro de cabeçalho no arquivo binário e no struct em ram
	c->status='0';//Define o campo 'status' do struct em ram
	for(int i=0;i<4;i++){//Realizado 4 vezes
		c->valoresCabecalho[i]=0;//Insere 0 nos campos "RRNproxRegistro","numeroRegistrosInseridos","numeroRegistrosRemovidos" e "numeroRegistrosAtualizados" do struct em ram 
	}

	if(tamanhoLixo==55){
		c->valoresCabecalho[0]=-1;
	}

	SalvarCabecalho(fpArquivoBinario,c);//Armazena no arquivo binário os campos do cabeçalho
	MarcarLixoArquivoBinario(fpArquivoBinario,tamanhoLixo);//Preenche com $ os demais 111 caracteres do registro de cabeçalho do arquivo binário

	return fpArquivoBinario;//Retorna o ponteiro do arquivo binário criado
}

//Abre o arquivo binário no modo leitura, retorna o ponteiro do arquivo e o cabeçalho
FILE* AbrirArquivoBinarioLeitura(char* nomeArquivoBinario,Cabecalho* c,int* erro){//Nome do arquivo binário, Endereço do struct cabecalho e endereço para armazenar o tipo de erro
	FILE* fpArquivoBinario=fopen(nomeArquivoBinario,"rb");//Abre o arquivo no modo leitura
	if(fpArquivoBinario==NULL){//Se o arquivo binário não existe ou houve algum erro ao abrir
		*erro=1;//Define o erro
		return NULL;
	}
	ObterCabecalho(fpArquivoBinario,c);//Obtém o Registro de Cabeçalho 
	if(c->status!='1'){//Se o arquivo está inconsistente
		*erro=1;//Define o erro
		fclose(fpArquivoBinario);
		return NULL;
	}

	return fpArquivoBinario;//Retorna o ponteiro do arquivo binário
}

//Abre o arquivo binário no modo escrita, retorna o ponteiro do arquivo e o cabeçalho
FILE* AbrirArquivoBinarioEscrita(char* nomeArquivoBinario,Cabecalho* c,int* erro){//Nome do arquivo binário, Endereço do struct cabeçalho e endereço para armazenar o tipo de erro
	FILE* fpArquivoBinario=fopen(nomeArquivoBinario,"rb+");//Abre o arquivo no modo escrita
	if(fpArquivoBinario==NULL){//Se o arquivo não existe ou houve algum erro ao abrir
		*erro=1;//Define o erro
		return NULL;
	}
	ObterCabecalho(fpArquivoBinario,c);//Obtém o Registro de Cabeçalho
	if(c->status!='1'){//Se o arquivo está inconsistente
		*erro=1;//Define o erro
		fclose(fpArquivoBinario);
		return NULL;
	}
	c->status='0';//Define o campo status do Cabeçalho para '0'
	SalvarCabecalho(fpArquivoBinario,c);//Salva o Cabeçalho
	return fpArquivoBinario;//Retorna o ponteiro do arquivo binário
}

//Fecha o arquivo binário, usado nas funcionalidades que alteram o arquivo binário
void FecharArquivoBinario(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo, Endereço do Cabeçalho
	c->status='1';//Define o status do Cabeçalho para '1'
	SalvarCabecalho(fpArquivoBinario,c);//Salva o Cabeçalho
	fclose(fpArquivoBinario);//Fecha o arquivo binário
}

//Lê um inteiro(4 bytes) do arquivo de entrada
void LerInteiroArquivoEntrada(FILE* fpArquivoEntrada,int* x){//ponteiro do arquivo e endereço da variável que vai armazenar o inteiro lido
	char c;
	fread(&c,1,1,fpArquivoEntrada);//Lê um caracter do arquivo
	if(c==','){//Se leu uma vírgula então não há inteiro para ser lido
		*x=-1;//variável recebe -1
	}else{
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Volta o ponteiro do arquivo um byte(volta o caracter lido)
		fscanf(fpArquivoEntrada,"%d,",x);//Lê o inteiro
	}
}

//Lê uma string do arquivo de entrada e retorna o tamamho da string lida
int LerStringArquivoEntrada(FILE* fpArquivoEntrada,char* str){//Ponteiro do arquivo e endereço para salvar a string
	int nCaracteres=0;//Armazena o número de caracteres lidos
	char charLido;//Armazena o caracter lido

	//Loop usado para ler e salvar cada caracter
	while(fread(&charLido,1,1,fpArquivoEntrada)){//Lê o caracter e armazena em charLido, sai do loop se o arquivo acabou
		if(charLido==',' || charLido=='\n'){//Se leu ',' ou '\n' então a string acabou
			break;//sai do loop
		}
		str[nCaracteres]=charLido;//Se leu um caracter válido então salva na string
		nCaracteres++;//Incrementa o número de caracteres lidos
	}

	if(nCaracteres==0){//Se tentou ler uma string que não está definida no arquivo de entrada(string nula)
		str[0]='\0';//Define o primeiro caracter da string como ' \0'
	}

	return nCaracteres;//Retorna o número de caracteres lidos
}

//Extrai um struct RegistroDados do arquivo de entrada, retorna 1 se a leitura foi bem sucedida, 0 caso contrário
int ObterRegistroArquivoEntrada(FILE* fpArquivoEntrada,RegistroDados* r){//Ponteiro do arquivo, endereço de um RegistroDados
	//Verificando se existe nascimento no arquivo de entrada para ser lido

	char teste;//Char usado para verificar se o arquivo acabou
	if(fread(&teste,1,1,fpArquivoEntrada)){//Tenta ler algum caracter, fread retorna 0 se o arquivo chegou ao fim
		fseek(fpArquivoEntrada,-1,SEEK_CUR);//Se o arquivo não acabou então volte o ponteiro um byte
	}else{
		return 0;//Se o arquivo acabou então retorne 0
	}

	//Lendo o nascimento e salvando no RegistroDados

	r->tamanhoCidadeMae=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeMae);//Lê a cidade da mãe e também obtém seu tamanho
	r->tamanhoCidadeBebe=LerStringArquivoEntrada(fpArquivoEntrada,r->cidadeBebe);//Lê a cidade do bebê e também obtém seu tamanho
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idNascimento));//Lê o id de nascimento
	LerInteiroArquivoEntrada(fpArquivoEntrada,&(r->idadeMae));//Lê a idade da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->dataNascimento);//Lê a data de nascimento
	LerStringArquivoEntrada(fpArquivoEntrada,&(r->sexoBebe));//Lê o sexo do bebê
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoMae);//Lê o estado da mãe
	LerStringArquivoEntrada(fpArquivoEntrada,r->estadoBebe);//Lê o estado do bebê
	return 1;//Retorna 1 indicando que a leitura foi bem sucedida
}

//Lê o arquivo binario e obtém dele um RegistroDados, retorna 0 se o arquivo binário acabou, -1 se tentou ler um registro lógicamente removido ou retorna 1 se a leitura foi bem sucedida
int ObterRegistroArquivoBinario(FILE* fpArquivoBinario,RegistroDados* r){//Ponteiro do arquivo binario e endereço de um RegistroDados para salvar os valores lidos
	if(fread(&(r->tamanhoCidadeMae),4,1,fpArquivoBinario)){//Lê um inteiro e armazena em r->tamanhoCidadeMae, fread retorna zero se o arquivo acabou
		if(r->tamanhoCidadeMae==-1){//Se valor lido é -1
			fseek(fpArquivoBinario,124,SEEK_CUR);//Coloca o ponteiro no início do próximo registro
			return -1;//leu registro lógicamente removido
		}
		fread(&(r->tamanhoCidadeBebe),4,1,fpArquivoBinario);//Lê o tamanhoCidadeBebe
		fread(r->cidadeMae,1,r->tamanhoCidadeMae,fpArquivoBinario);//Lê a cidadeMae
		fread(r->cidadeBebe,1,r->tamanhoCidadeBebe,fpArquivoBinario);//Lê a cidadeBebe
		fseek(fpArquivoBinario,97-(r->tamanhoCidadeMae)-(r->tamanhoCidadeBebe),SEEK_CUR);//Pula o lixo das string de tamanho variável
		fread(&(r->idNascimento),4,1,fpArquivoBinario);//Lê o idNascimento
		fread(&(r->idadeMae),4,1,fpArquivoBinario);//Lê a idadeMae
		fread(r->dataNascimento,1,10,fpArquivoBinario);//Lê a dataNascimento
		fread(&(r->sexoBebe),1,1,fpArquivoBinario);//Lê o sexoBebe
		fread(r->estadoMae,1,2,fpArquivoBinario);//Lê o estadoMae
		fread(r->estadoBebe,1,2,fpArquivoBinario);//Lê o estadoBebe
		return 1;//Leitura bem sucedida
	}
	return 0;//Erro, arquivo acabou
}

//Retorna um inteiro digitado pelo usuário
int ObterInteiroUsuario(){
	char str[98];//String para armazenar o número digitado
	scan_quote_string(str);//Retira as aspas da string
	if(strcmp(str,"")==0){//Se a string é nula
		return -1;//Retorna -1 como valor para ser armazenado no inteiro
	}
	return atoi(str);//Converte a string em inteiro
}

//Obtém um vetor de ParCampoValor digitado pelo usuários
void ObterVetorParCampoValor(int nPares,ParCampoValor* vetorCb){//Numero de pares, endereço para armazenar os pares
	for(int i=0;i<nPares;i++){//Faz a leitura do campo e do valor em cada volta do laço
		scanf("%s",vetorCb[i].campoBusca);//Lê o campo

		//Se o campo aceita valores inteiros
		if(strcmp(vetorCb[i].campoBusca,"tamanhoCidadeMae")==0 ||
				strcmp(vetorCb[i].campoBusca,"tamanhoCidadeBebe")==0 ||
				strcmp(vetorCb[i].campoBusca,"idNascimento")==0 ||
				strcmp(vetorCb[i].campoBusca,"idadeMae")==0){
			vetorCb[i].valorBuscaInt=ObterInteiroUsuario();//Lê o inteiro digitado pelo usuario
		}else{//Se é um campo de valores string
			scan_quote_string(vetorCb[i].valorBuscaStr);//Lê a string
		}
	}
}

//Função para obter um Registro de Dados do usuário seguindo a especificação da funcionalidade 6
void ObterRegistroUsuario(RegistroDados* r){//Endereço de um RegistroDados para salvar os valores lidos
	char aux[98];
	scan_quote_string(aux);//Lê a cidadeMae
	strncpy(r->cidadeMae,aux,strlen(aux));
	r->tamanhoCidadeMae=strlen(aux);//Define o tamanho da cidadeMae

	scan_quote_string(aux);//Lê a cidadeBebe
	strncpy(r->cidadeBebe,aux,strlen(aux));
	r->tamanhoCidadeBebe=strlen(aux);//Define o tamanho da cidadeBebe

	r->idNascimento=ObterInteiroUsuario();//Lê o idNascimento

	r->idadeMae=ObterInteiroUsuario();//Lê a idadeMae

	scan_quote_string(aux);//Lê a dataNascimento
	strncpy(r->dataNascimento,aux,10);

	scan_quote_string(aux);//Lê o sexoBebe
	strncpy(&(r->sexoBebe),aux,1);

	scan_quote_string(aux);//Lê o estadoMae
	strncpy(r->estadoMae,aux,2);

	scan_quote_string(aux);//Lê o estadoBebe
	strncpy(r->estadoBebe,aux,2);
}

//Salva uma string no arquivo binário gerado, usado para salvar string em campos de tamanho fixo
void SalvarStringArquivoBinario(char* str,int tamanho,FILE* fpArquivoBinario){//string que será salva, tamanho da string e ponteiro do arquivo
	if(str[0]=='\0'){//Se o primeiro char da string é '\0'(string nula)
		fwrite(str,1,1,fpArquivoBinario);//Insere o '\0'
		MarcarLixoArquivoBinario(fpArquivoBinario,tamanho-1);//Prenche o resto do campo com $
	}else{//Se a string não é nula
		fwrite(str,1,tamanho,fpArquivoBinario);//Salva a string
	}
}

//Salva um Registro de Dados no Arquivo binário na posição atual do ponteiro, não muda o Cabeçalho
void SalvarRegistroArquivoBinario(FILE* fpArquivoBinario,RegistroDados r,int manterLixo){//Ponteiro do arquivo, Endereço do Registro a ser salvo e inteiro que indica se deve ou não manter o lixo no caso de atualização de Registro
	//Salvando o RegistroDados
	fwrite(&(r.tamanhoCidadeMae),4,1,fpArquivoBinario);//Escreve o tamanhoCidadeMae no arquivo binário
	fwrite(&(r.tamanhoCidadeBebe),4,1,fpArquivoBinario);//Escreve o tamanhoCidadeBebe no arquivo binário

	if(r.tamanhoCidadeMae!=0){//Se cidadeMae não é nula
		fwrite(r.cidadeMae,1,r.tamanhoCidadeMae,fpArquivoBinario);//Escreve cidadeMae no arquivo binário
	}
	if(r.tamanhoCidadeBebe!=0){//Se cidadeBebe não é nula
		fwrite(r.cidadeBebe,1,r.tamanhoCidadeBebe,fpArquivoBinario);//Escreve cidadeBebe no arquivo
	}
	if(manterLixo==0){//Se não é para manter o lixo do campo anterior
		MarcarLixoArquivoBinario(fpArquivoBinario,97-r.tamanhoCidadeMae-r.tamanhoCidadeBebe);//Preenche o resto dos campos de string de tamanho variável com lixo
	}else{//Se é para manter o lixo
		fseek(fpArquivoBinario,97-r.tamanhoCidadeMae-r.tamanhoCidadeBebe,SEEK_CUR);//Move o ponteiro para o campo "idNascimento"
	}
	fwrite(&(r.idNascimento),4,1,fpArquivoBinario);//Escreve o idNascimento no arquivo binário
	fwrite(&(r.idadeMae),4,1,fpArquivoBinario);//Escreve a idadeMae no arquvivo binário

	SalvarStringArquivoBinario(r.dataNascimento,10,fpArquivoBinario);//Salva a dataNascimento no arquivo binário
	if(r.sexoBebe=='\0'){//Se o sexoBebe for '\0' então salva '0' no arquivo binário
		r.sexoBebe='0';
	}
	fwrite(&(r.sexoBebe),1,1,fpArquivoBinario);//Salva o sexoBebe no arquivo binário
	SalvarStringArquivoBinario(r.estadoMae,2,fpArquivoBinario);//Salva estadoMae no arquivo binário
	SalvarStringArquivoBinario(r.estadoBebe,2,fpArquivoBinario);//Salva estadoBebe no arquivo binário

}

//Remove o Registro na posição atual do ponteiro do arquivo binário
void RemoverRegistroArquivoBinario(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo, Endereço do Cabeçalho
	//Atualiza o Cabeçalho
	c->valoresCabecalho[1]--;//Decrementa numeroRegistrosInseridos
	c->valoresCabecalho[2]++;//Incrementa numeroRegistrosRemovidos
	int aux=-1;
	fwrite(&aux,4,1,fpArquivoBinario);//Escreve -1 no arquivo binário
}

//Função que exibe uma string sem '\0' no final
void ExibirString(char* str,int tam){//Ponteiro para início da string, tamanho da string
	if(tam==0 || str[0]=='\0'){//Se o tamanho da string é zero(campo de tamanho variavel) ou se ela começa com '\0'(campo de tamanho fixo) então exibe "-"
		printf("-");
	}else{//String não é nula
		for(int i=0;i<tam;i++){//Exibe um caracter por vez
			printf("%c",str[i]);
		}
	}
}

//Função que recebe um struct RegistroDados e o exibe na tela conforme especificação da funcionalidade 2
void MostrarRegistroDados(RegistroDados r){//Registro a ser exibido
	printf("Nasceu em ");
	ExibirString(r.cidadeBebe,r.tamanhoCidadeBebe);//Exibe a cidade de nascimento do bebê
	printf("/");
	ExibirString(r.estadoBebe,2);//Exibe o estado de nascimento do bebê
	printf(", em ");
	ExibirString(r.dataNascimento,10);//Exibe a data do nascimento
	printf(", um bebê de sexo ");
	if(r.sexoBebe=='0'){//Analisa o valor de sexoBebe para exibir o sexo da criança
		printf("IGNORADO.\n");
	}else if(r.sexoBebe=='1'){
		printf("MASCULINO.\n");
	}else{
		printf("FEMININO.\n");
	}
}

//Retorna 1 se o Registro possui o valor procurado no campo procurado, 0 caso contrário
int VerificarCampoRegistro(RegistroDados* r,ParCampoValor* cb){//Endereço do Registro a ser verificado e Endereço do struct com o campo e o valor procurado
	if(strncmp(cb->campoBusca,"tamanhoCidadeMae",16)==0){//Se campo a ser verificado é o tamanhoCidadeMae
		if(r->tamanhoCidadeMae==cb->valorBuscaInt){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"tamanhoCidadeBebe",17)==0){//Se campo a ser verificado é o tamanhoCidadeBebe
		if(r->tamanhoCidadeBebe==cb->valorBuscaInt){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"idNascimento",12)==0){//Se campo a ser verificado é o idNascimento
		if(r->idNascimento==cb->valorBuscaInt){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"idadeMae",8)==0){//Se campo a ser verificado é o idadeMae
		if(r->idadeMae==cb->valorBuscaInt){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"cidadeMae",9)==0){//Se campo a ser verificado é o cidadeMae
		if(r->tamanhoCidadeMae==strlen(cb->valorBuscaStr) && strncmp(r->cidadeMae,cb->valorBuscaStr,r->tamanhoCidadeMae)==0){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"cidadeBebe",10)==0){//Se campo a ser verificado é o cidadeBebe
		if(r->tamanhoCidadeBebe==strlen(cb->valorBuscaStr) && strncmp(r->cidadeBebe,cb->valorBuscaStr,r->tamanhoCidadeBebe)==0){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"dataNascimento",14)==0){//Se campo a ser verificado é o dataNascimento
		if(strncmp(r->dataNascimento,cb->valorBuscaStr,10)==0){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"sexoBebe",8)==0){//Se campo a ser verificado é o sexoBebe
		if(cb->valorBuscaStr[0]=='\0'){//Se está procurando por '\0'
			cb->valorBuscaStr[0]='0';//Passa a procurar '0'(valor de sexoBebe IGNORADO no RegistroDados)
		}
		if(r->sexoBebe==cb->valorBuscaStr[0]){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"estadoMae",9)==0){//Se campo a ser verificado é o estadoMae
		if(strncmp(r->estadoMae,cb->valorBuscaStr,2)==0){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}else if(strncmp(cb->campoBusca,"estadoBebe",10)==0){//Se campo a ser verificado é o estadoBebe
		if(strncmp(r->estadoBebe,cb->valorBuscaStr,2)==0){//Se valor do campo é igual ao valor buscado
			return 1;//Registro satisfaz o par campo valor
		}
	}

	return 0;//Registro não satisfaz o par campo valor
}

//Verifica se um Registro satisfaz uma busca combinada
int VerificarBuscaCombinada(RegistroDados* r,ParCampoValor* vetorCb,int nPares){//Registro, vetor de par campo valor e número de pares campo valor
	if(r->tamanhoCidadeMae==-1){//Se Registro está marcado como removido
		return 0;//Nâo satisfaz a busca combinada
	}

	for(int i=0;i<nPares;i++){//Executa nPares vezes
		if(VerificarCampoRegistro(r,vetorCb+i)==0){//Se o registro não satisfaz o i-ésimo par
			return 0;//Não satisfaz a busca combinada
		}
	}
	return 1;//Satisfaz a busca combinada
}

//Altera um campo do Registro
void AlterarCampoRegistro(RegistroDados* r,ParCampoValor* cb){//Endereço do Registro e Endereço do struct com o campo e valor a ser alterado
	if(strncmp(cb->campoBusca,"idNascimento",12)==0){//Se campo a ser alterado é o idNascimento
		r->idNascimento=cb->valorBuscaInt;
	}else if(strncmp(cb->campoBusca,"idadeMae",8)==0){//Se campo a ser alterado é o idadeMae
		r->idadeMae=cb->valorBuscaInt;
	}else if (strncmp(cb->campoBusca,"cidadeMae",9)==0){//Se campo a ser alterado é o cidadeMae
		strncpy(r->cidadeMae,cb->valorBuscaStr,strlen(cb->valorBuscaStr));
		r->tamanhoCidadeMae=strlen(cb->valorBuscaStr);
	}else if(strncmp(cb->campoBusca,"cidadeBebe",10)==0){//Se campo a ser alterado é o cidadeBebe
		strncpy(r->cidadeBebe,cb->valorBuscaStr,strlen(cb->valorBuscaStr));
		r->tamanhoCidadeBebe=strlen(cb->valorBuscaStr);
	}else if(strncmp(cb->campoBusca,"dataNascimento",14)==0){//Se campo a ser alterado é o dataNascimento
		strncpy(r->dataNascimento,cb->valorBuscaStr,10);
	}else if(strncmp(cb->campoBusca,"sexoBebe",8)==0){//Se campo a ser alterado é o sexoBebe
		r       ->sexoBebe=cb->valorBuscaStr[0];
	}else if(strncmp(cb->campoBusca,"estadoMae",9)==0){//Se campo a ser alterado é o estadoMae
		strncpy(r->estadoMae,cb->valorBuscaStr,2);
	}else if(strncmp(cb->campoBusca,"estadoBebe",10)==0){//Se campo a ser alterado é o estadoBebe
		strncpy(r->estadoBebe,cb->valorBuscaStr,2);
	}
}

//Altera um Registro de acordo com o vetor de ParCampoValor
void AlterarRegistro(RegistroDados* r,ParCampoValor* vetorCb,int nParesBusca){//Endereço do Registro a ser alterado, vetor de ParCampoValor e número de pares no vetor
	for(int i=0;i<nParesBusca;i++){//Um par por volta do laço
		AlterarCampoRegistro(r,vetorCb+i);//Altera um campo do Registro
	}
}

//Atualiza o Registro na posição atual do ponteiro do arquivo binário
void AtualizarRegistroArquivoBinario(FILE* fpArquivoBinario,Cabecalho* c,RegistroDados* r){//Ponteiro do arquivo binário, Cabeçalho e Registro a ser inserido
	SalvarRegistroArquivoBinario(fpArquivoBinario,*r,1);//Insere o Registro na posição atual do ponteiro
	c->valoresCabecalho[3]++;//Incrementa numeroRegistrosAtualizados
}

//Coloca o ponteiro do arquivo binário no início do Registro de RRN especificado
int IrParaRRN(FILE* fpArquivoBinario,int RRN){//Ponteiro do arquivo binário e RRN desejado
	if(fseek(fpArquivoBinario,128*(RRN+1),SEEK_SET)!=0){//Se der erro ao dar fseek, fseek retorna algo diferente de 0 em caso de erro
		return 0;//Erro
	}
	return 1;//Sucesso
}

//Lê os nascimentos do arquivo de entrada e os armazena no arquivo binário, fechas os 2 arquivos
void Funcionalidade1(FILE* fpArquivoEntrada,FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo de entrada, ponteiro do arquivo binário e endereço do cabeçalho	
	//Loop que obtém os registros do arquivo de entrada e os salva no arquivo binário gerado
	fseek(fpArquivoEntrada,88,SEEK_SET);//Pula a primeira linha do arquivo de entrada
	RegistroDados r;//Registro que será usado para armazenar as informações antes de serem armazenadas no arquivo binário
	fseek(fpArquivoBinario,(1+c->valoresCabecalho[0])*128,SEEK_SET);//Vai para o final do arquivo binário	
	while(ObterRegistroArquivoEntrada(fpArquivoEntrada,&r)){//Lê o arquivo de entrada e obtém um RegistroDados, sai do loop quando o arquivo de entrada acabar
		//Insere no final
		SalvarRegistroArquivoBinario(fpArquivoBinario,r,0);

		//Incrementando os campos do registro de cabeçalho
		c->valoresCabecalho[0]++;//Incrementa RRNproxRegistro
		c->valoresCabecalho[1]++;//Incrementa numeroRegistrosInseridos
	}

	//Fecha os arquivos
	fclose(fpArquivoEntrada);
	FecharArquivoBinario(fpArquivoBinario,c);
}

//Exibe na tela os Registros do arquivo binário
void Funcionalidade2(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo binário
	//Loop para exibir os arquivos	
	RegistroDados r;//RegistroDados que armazena as informações a serem exibidas
	if(c->valoresCabecalho[1]!=0){
		fseek(fpArquivoBinario,128,SEEK_SET);//Pula o registro de cabeçalho do arquivo binario
		while(ObterRegistroArquivoBinario(fpArquivoBinario,&r)){//Obtém um Registro do arquivo binário, função retorna 0 se arquivo binário acabou
			if(r.tamanhoCidadeMae!=-1){//Se Registro obtido não está marcado como logicamente removido	
				MostrarRegistroDados(r);//Exibe o registro na tela
			}
		}
	}else{
		printf("Registro inexistente.\n");
	}
	fclose(fpArquivoBinario);//Fecha o arquivo binário
}

//Exibe na tela os Registros que satisfazem a busca do usuário
void Funcionalidade3(FILE* fpArquivoBinario){//Ponteiro do arquivo binário
	int nParesBusca,contador=0;//Váriáveis para armazenar o número de pares de campo e valores e uma variável para contar quantos registros foram exibidos
	scanf("%d",&nParesBusca);//Lê o número de pares campo valor
	ParCampoValor vetorCb[nParesBusca];//Cria um vetor para armazenar os pares de campo e valor
	ObterVetorParCampoValor(nParesBusca,vetorCb);//Obtém o vetor de pares de campo e valor

	RegistroDados r;//Registro auxiliar para armazenar as informaçõesa a serem exibidas
	fseek(fpArquivoBinario,128,SEEK_SET);//Pula o Registro de Cabeçalho do arquivo binário
	while(ObterRegistroArquivoBinario(fpArquivoBinario,&r)){//Obtém um Registro do arquivo binário, função retorna 0 se o arquivo binário acabou
		if(VerificarBuscaCombinada(&r,vetorCb,nParesBusca)==1){//Se o registro obtido satisfaz a busca do usuário
			MostrarRegistroDados(r);//Exibe o registro
			contador++;//Incrementa o contador de registros exibidos
		}
	}
	if(contador==0){//Se após varrer o arquivo binário não foi exibido nenhum Registro
		printf("Registro Inexistente.\n");//Exibe mensagem de erro
	}
	fclose(fpArquivoBinario);//Fecha o arquivo binário
}

//Exibe um Registro de RRN especificado
void Funcionalidade4(FILE* fpArquivoBinario){//Ponteiro do arquivo binário
	int RRN;//Variável para armazenar o RRN procurado
	RegistroDados r;//Registro para armazenar o Registro no RRN especificado
	scanf("%d",&RRN);//Lê o RRN
	if(IrParaRRN(fpArquivoBinario,RRN)==1 && ObterRegistroArquivoBinario(fpArquivoBinario,&r)==1){//Vai para o RRN e obtém o Registro, entra no if se posição existe e Registro não está removido
		MostrarRegistroDados(r);//Exibe o Registro
	}else{
		printf("Registro Inexistente.\n");//Se a posição desejada não existe ou está marcado como removido
	}
	fclose(fpArquivoBinario);//Fecha o arquivo binário
}

//Remove Registros de acordo com a busca do usuário
void Funcionalidade5(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo binário e Endereço do Cabeçalho
	int n,m;//Variáveis da especificação
	RegistroDados r;//Registro auxiliar
	scanf("%d",&n);//Lê n
	for(int i=0;i<n;i++){//Executa n vezes
		scanf("%d",&m);//Lê m
		ParCampoValor vetorCb[m];//Cria um vetor de ParCampoVetor de tamanho m
		ObterVetorParCampoValor(m,vetorCb);//Obtém o vetor de ParCampoVetor
		fseek(fpArquivoBinario,128,SEEK_SET);//Pula o Registro de Cabaçalho
		while(ObterRegistroArquivoBinario(fpArquivoBinario,&r)){//Obtém um Registro do arquivo binário, função retorna 0 quando arquivo binário acabou
			if(VerificarBuscaCombinada(&r,vetorCb,m)==1){//Se Registro obtido satisfaz a busca
				fseek(fpArquivoBinario,-128,SEEK_CUR);//Volta o ponteiro do arquivo binário para o início do Registro que satisfaz a busca
				RemoverRegistroArquivoBinario(fpArquivoBinario,c);//Remove o Registro
				fseek(fpArquivoBinario,124,SEEK_CUR);//Cololca o ponteiro do arquivo binário no início do próximo Registro
			}
		}

	}
	FecharArquivoBinario(fpArquivoBinario,c);//Fecha o arquivo binário
}

//Lê do usuário um novo Registro de Dados e insere no final do arquivo
void Funcionalidade6(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo binário e Endereço do Cabeçalho
	int n;//Variável da especificação
	RegistroDados r;//Registro de Dados para armazenar os valores digitado pelo usuário
	scanf("%d",&n);//Lê n
	fseek(fpArquivoBinario,(1+c->valoresCabecalho[0])*128,SEEK_SET);//Vai para o final do arquivo binário
	for(int i=0;i<n;i++){//Executa n vezes
		ObterRegistroUsuario(&r);//Obtém o Registro digitado pelo usuário
		SalvarRegistroArquivoBinario(fpArquivoBinario,r,0);//Insere no final

		//Incrementando os campos do registro de cabeçalho
		c->valoresCabecalho[0]++;//Incrementa RRNproxRegistro
		c->valoresCabecalho[1]++;//Incrementa numeroRegistrosInseridos
	}
	FecharArquivoBinario(fpArquivoBinario,c);//Fecha o arquivo binário
}

//Atualiza Registros de RRN especificado pelo usuário
void Funcionalidade7(FILE* fpArquivoBinario,Cabecalho* c){//Ponteiro do arquivo binário, Endereço do Cabeçalho
	int n,rrn,m;//Variáveis da especificação da funcionalidade
	RegistroDados r;//Registro auxiliar
	scanf("%d",&n);//Lê n
	for(int i=0;i<n;i++){//Executa n vezes
		scanf("%d %d",&rrn,&m);//Lê RRN e m
		IrParaRRN(fpArquivoBinario,rrn);//Vai para o RRN especificado
		ParCampoValor vetorCb[m];//Vetor para armazenar os pares de campo e valor
		ObterVetorParCampoValor(m,vetorCb);//Obtém o vetor de par campo e valor do usuário
		if(ObterRegistroArquivoBinario(fpArquivoBinario,&r)==1){//Obtém o Registro do RRN especificado, função retorna 1 se RRN existe e não está removido
			AlterarRegistro(&r,vetorCb,m);//Altera o Registro de acordo com o vetor de par campo e valor
			fseek(fpArquivoBinario,-128,SEEK_CUR);//Volta o ponteiro para o início do Registro a ser atualizado
			AtualizarRegistroArquivoBinario(fpArquivoBinario,c,&r);//Insere o novo Registro 
		}
	}
	FecharArquivoBinario(fpArquivoBinario,c);//Fecha o arquivo binário
}

//Cria a árvore B do arquivo desejado
void Funcionalidade8(FILE* fpArquivoBinario,FILE* fpArvoreB,Cabecalho* cDados,Cabecalho* cArvore){//Ponteiro do arquivo binário, ponteiro do arquivo de árvore, Cabecalho do arquivo binário
	//Cabecalho do arquivo de árvore
	fseek(fpArquivoBinario,128,SEEK_SET);//Posiciona o ponteiro no início do primeiro Registro de dados
	RegistroDados r;//Registro para armazenar o Registro de dados
	Chave ch;//Chave para armazenar os valores a serem inseridos na árvore
	int RRNRegistro=0;//Variável para armazenar o RRN do Registro atual
	while(ObterRegistroArquivoBinario(fpArquivoBinario,&r)){//Obtém um registro do arquivo de dados, função retorna 0 quando arquivo acabou
		if(r.tamanhoCidadeMae!=-1){//Se Registro obtido não está removido
			ch.chaveBusca=r.idNascimento;//Chave de busca da árvore é o id do registro
			ch.RRNReferencia=RRNRegistro;//RRNReferencia da chave é o RRN do Registro atual
			InsercaoArvoreB(fpArvoreB,cArvore,ch);//Insere a chave na árvore B
		}
		RRNRegistro++;//Incrementa o RRN atual
	}
	fclose(fpArquivoBinario);//Fecha o arquivo de dados
	FecharArquivoBinario(fpArvoreB,cArvore);//Fecha o arquivo da árvore
}

//Procura um Registro na árvore e o exibe
void Funcionalidade9(FILE* fpArquivoBinario,FILE* fpArvoreB,Cabecalho* cArvore){//Ponteiro do arquivo de dados, ponteiro do arquivo de árvore B, Cabeçalho da árvore
	RegistroDados r;//Registro para armazenar as informações
	int valor,nNiveisPercorridos=0;//Variáveis para armazenar o valor procurado e a quantidade de níveis percorridos durante a busca
	char lixo[13];//String para armazenar o "idNascimento"
	scanf("%s %d",lixo,&valor);//Lê o "idNascimento" e o id procurado

	//Procura a chave e armazena o RRN encontrado
	int RRNDesejado=BuscarArvoreBRecursiva(fpArvoreB,cArvore->valoresCabecalho[0],valor,&nNiveisPercorridos);//Ponteiro da árvore, RRN do nó raiz, chave desejada e endereço para armazenar o número de níveis procurados
	if(RRNDesejado==-1){//Se não encontrou o valor
		printf("Registro inexistente.\n");//Exibe mensagem de erro
	}else{
		if(IrParaRRN(fpArquivoBinario,RRNDesejado)){//Vai para o RRN desejado
			if(ObterRegistroArquivoBinario(fpArquivoBinario,&r)==1){//Obtém o Registro do RRN atual, função retorna 0 se o Registro está marcado como removido
				MostrarRegistroDados(r);//Exibe o Registro
				printf("Quantidade de paginas da arvore-B acessadas: %d\n",nNiveisPercorridos);//Exibe o número de níveis percorridos
			}else{
				printf("Registro inexistente.\n");//Exibe mensagem de erro se Registro está marcado como removido
			}
		}
	}
	fclose(fpArquivoBinario);//Fecha o arquivo de dados
	fclose(fpArvoreB);//Fecha o arquivo da árvore
}

//Adiciona Registros no arquivo binário e arquivo da árvore
void Funcionalidade10(FILE* fpArquivoBinario,FILE* fpArvoreB,Cabecalho* cDados,Cabecalho* cArvore){//Ponteiro do arquivo de dados, ponteiro do arquivo da árvore, cabeçalho do arquio de dados e cabaçalho do arquivo da árvore
	int n;//Armazena o número de inserções
	Chave ch;//Chave para armazenar os valores a serem inseridos na árvore
	RegistroDados r;//Registro para armazenar os valores do registro a ser inserido
	scanf("%d",&n);//Lê e armazena o número de inserções

	fseek(fpArquivoBinario,(1+cDados->valoresCabecalho[0])*128,SEEK_SET);//Vai para o final do arquivo binário
	for(int i=0;i<n;i++){//Executa n vezes
		ObterRegistroUsuario(&r);//Obtém o Registro digitado pelo usuário
		ch.chaveBusca=r.idNascimento;//Define a chave de busca como o idNascimento do Registro
		ch.RRNReferencia=cDados->valoresCabecalho[0];//Define o RRNReferencia da chave como o proxRRN do cabeçalho do arquivo de dados
		SalvarRegistroArquivoBinario(fpArquivoBinario,r,0);//Insere o registro no final do arquivo de dados
		InsercaoArvoreB(fpArvoreB,cArvore,ch);//Insere a chave na árvore
		//Incrementando os campos do registro de cabeçalho
		cDados->valoresCabecalho[0]++;//Incrementa RRNproxRegistro
		cDados->valoresCabecalho[1]++;//Incrementa numeroRegistrosInseridos
	}
	FecharArquivoBinario(fpArquivoBinario,cDados);//Fecha o arquivo de dados
	FecharArquivoBinario(fpArvoreB,cArvore);//Fecha o arquivo da árvore
}

//Lê a funcionalidade desejada e faz a leitura dos argumentos necessários
int main(){
	char nomeArquivoAux[100],nomeArquivoBinario[100];//char para armazenar a operação desejada e strings para armazenar os argumentos
	FILE* fpArquivoAux,*fpArquivoBinario;//Ponteiros de arquivo
	int op,erro=0;//Variável para armazenar o tipo de erro
	Cabecalho cDados,cArvore;//Struct para armazenar os valores do Registro de Cabeçalho
	scanf("%d",&op);//Lê a operação desejada

	//Abre ou Cria o arquivo binário
	if(op==1){//Se operação 1
		//Cria o arquivo binário e abre o arquivo de entrada
		scanf("%s %s",nomeArquivoAux,nomeArquivoBinario);//Lê o nome do arquivo de entrada e do arquivo binario
		fpArquivoBinario=CriarArquivoBinario(nomeArquivoBinario,&cDados,&erro,111);//Cria o arquivo binário
		fpArquivoAux=fopen(nomeArquivoAux,"r");//Abre o arquivo de entrada no modo leitura

		if(fpArquivoAux==NULL || fpArquivoBinario==NULL){//Se houve erro ao abrir arquivo de entrada ou criar arquivo binário
			printf("Falha no carregamento do arquivo.\n");//Exibe mensagem de erro
			return 0;//Acaba a main
		}

	}else if((op>=2 && op<=4) || op==8 || op==9){//Se for operação 2,3 ou 4
		scanf("%s",nomeArquivoBinario);//Lê o nome do arquivo binário
		fpArquivoBinario=AbrirArquivoBinarioLeitura(nomeArquivoBinario,&cDados,&erro);//Abre o arquivo binário no modo leitura e faz as verificações
	}else{//Se for operação 5,6 ou 7
		scanf("%s",nomeArquivoBinario);//Lê o nome do arquivo binário
		fpArquivoBinario=AbrirArquivoBinarioEscrita(nomeArquivoBinario,&cDados,&erro);//Abre o arquivo binário no modo escrita
	}

	//Verifica se houve erro ao abrir ou criar o arquivo
	if(erro!=0){//Se houve algum erro ao abrir os arquivos
		if(erro==1){//Se houve erro ao processar o arquivo
			printf("Falha no processamento do arquivo.\n");
		}
		return 0;//Acaba a main
	}

	if(op>=8 && op<=10){//Se a operação envolve arquivo de árvore B
		scanf("%s",nomeArquivoAux);//Lê o nome do arquivo
		if(op==8){//Se for operação 8
			fpArquivoAux=CriarArquivoBinario(nomeArquivoAux,&cArvore,&erro,55);//Cria o arquivo da árvore
		}else if(op==9){//Se for operação 9
			fpArquivoAux=AbrirArquivoBinarioLeitura(nomeArquivoAux,&cArvore,&erro);//Abre o arquivo da árvore no modo leitura
		}else{
			fpArquivoAux=AbrirArquivoBinarioEscrita(nomeArquivoAux,&cArvore,&erro);//Abre o arquivo da árovre no modo escrita
		}
		if(erro!=0){//Se houve erro
			if(erro==1){
				printf("Falha no processamento do arquivo\n");
			}else{
				printf("Registro inexistente.\n");
			}
			return 0;
		}
	}

	//Chama a operação correta
	switch(op){
		case 1://Funcionalidade 1
			Funcionalidade1(fpArquivoAux,fpArquivoBinario,&cDados);//Chama a funcionalidade1
			break;
		case 2://Funcionalidade 2
			Funcionalidade2(fpArquivoBinario,&cDados);//Chama a funcionalidade2
			break;
		case 3://Funcionalidade 3
			Funcionalidade3(fpArquivoBinario);//Chama a funcionalidade3
			break;
		case 4://Funcionalidade 4
			Funcionalidade4(fpArquivoBinario);//Chama a funcionalidade4
			break;
		case 5://Funcionalidade 5
			Funcionalidade5(fpArquivoBinario,&cDados);//Chama a funcionalidade5
			break;
		case 6://Funcionalidade 6
			Funcionalidade6(fpArquivoBinario,&cDados);//Chama a funcionalidade6
			break;
		case 7://Funcionalidade 7
			Funcionalidade7(fpArquivoBinario,&cDados);//Chama a funcionalidade7
			break;
		case 8://Funcionalidade 8
			Funcionalidade8(fpArquivoBinario,fpArquivoAux,&cDados,&cArvore);//Chama a funcionalidade8
			break;
		case 9://Funcionalidade 9
			Funcionalidade9(fpArquivoBinario,fpArquivoAux,&cArvore);//Chama a funcionalidede9
			break;
		case 10://Funcionalidade 10
			Funcionalidade10(fpArquivoBinario,fpArquivoAux,&cDados,&cArvore);//Chama a funcionalidade10
			break;
	}

	//Chama a binarioNaTela
	if(op==1 || (op>=5 && op<=7)){//Se for operação 1,5,6 ou 7
		binarioNaTela(nomeArquivoBinario);//Chama a binarioNaTela
	}

	if(op==8 || op==10){//Se for operação que envolve árvore B
		binarioNaTela(nomeArquivoAux);//Chama a binarioNaTela
	}

	return 0;//Sai do programa
}
