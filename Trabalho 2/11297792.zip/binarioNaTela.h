//11275338 Leonardo Antonetti da Motta
//11297792 Olavo Morais Borges Pereira
//Header com os protótipos das funções fornecidas
#ifndef binarioNaTela_h
#define binarioNaTela_h

void binarioNaTela(char *nomeArquivoBinario);
void trim(char *str);
void scan_quote_string(char *str);

#endif

